const admin = require('firebase-admin');

let db = null;

function initFirebase() {
    try {
        if (admin.apps.length === 0) {
            const serviceAccount = {
                type: 'service_account',
                project_id: process.env.FIREBASE_PROJECT_ID,
                private_key: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
                client_email: process.env.FIREBASE_CLIENT_EMAIL,
            };

            if (serviceAccount.project_id && serviceAccount.private_key && serviceAccount.client_email) {
                admin.initializeApp({
                    credential: admin.credential.cert(serviceAccount),
                    ignoreUndefinedProperties: true
                });
                db = admin.firestore();
                console.log('[Firebase] Initialized successfully');
            } else {
                console.log('[Firebase] Credentials not configured, running without Firebase');
            }
        }
    } catch (err) {
        console.log('[Firebase] Initialization failed, running without Firebase:', err.message);
    }
}

function cleanData(data) {
    if (!data || typeof data !== 'object') return data;
    var cleaned = {};
    Object.keys(data).forEach(function (key) {
        if (data[key] !== undefined && data[key] !== null) {
            cleaned[key] = data[key];
        }
    });
    return cleaned;
}

async function logToFirebase(collection, data) {
    if (!db) return;
    try {
        await db.collection(collection).add({
            ...cleanData(data),
            timestamp: admin.firestore.FieldValue.serverTimestamp()
        });
    } catch (err) {
        console.log('[Firebase] Failed to log to ' + collection + ':', err.message);
    }
}

async function getFirebaseLogs(collection, limit) {
    limit = limit || 100;
    if (!db) return [];
    try {
        var snapshot = await db.collection(collection)
            .orderBy('timestamp', 'desc')
            .limit(limit)
            .get();
        return snapshot.docs.map(function (doc) { return Object.assign({ id: doc.id }, doc.data()); });
    } catch (err) {
        console.log('[Firebase] Failed to read ' + collection + ':', err.message);
        return [];
    }
}

module.exports = { initFirebase, logToFirebase, getFirebaseLogs };
