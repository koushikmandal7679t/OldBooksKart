const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fallback_refresh_secret';

function generateTokens(payload) {
    const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
    const refreshToken = jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: '30d' });
    return { accessToken, refreshToken };
}

function verifyAccessToken(token) {
    try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}

function verifyRefreshToken(token) {
    try { return jwt.verify(token, JWT_REFRESH_SECRET); } catch { return null; }
}

function getCookieOptions() {
    var cookieDomain = process.env.COOKIE_DOMAIN;
    var hasDomain = cookieDomain && cookieDomain.trim().length > 0;

    /*
     * Localhost mode (no COOKIE_DOMAIN set):
     *   sameSite: lax, secure: false — works on HTTP
     *
     * Production mode (COOKIE_DOMAIN set, e.g. .yourdomain.com):
     *   sameSite: none, secure: true — works cross-domain on HTTPS
     */
    if (hasDomain) {
        return { httpOnly: true, secure: true, sameSite: 'none', path: '/', domain: cookieDomain };
    }
    return { httpOnly: true, secure: false, sameSite: 'lax', path: '/' };
}

function setCookie(res, name, value, maxAge) {
    var options = Object.assign({}, getCookieOptions(), { maxAge: maxAge });
    res.cookie(name, value, options);
}

function clearCookie(res, name) {
    var options = getCookieOptions();
    res.clearCookie(name, options);
}

function authenticate(req, res, next) {
    var accessToken = req.cookies && req.cookies.accessToken;
    if (!accessToken) {
        return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    var decoded = verifyAccessToken(accessToken);
    if (!decoded) {
        return res.status(401).json({ success: false, message: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    var users = req.app.locals.users;
    var user = users.get(decoded.email);
    if (!user || user.blocked) {
        return res.status(401).json({ success: false, message: 'User not found or blocked' });
    }
    req.user = user;
    next();
}

function optionalAuth(req, res, next) {
    var accessToken = req.cookies && req.cookies.accessToken;
    if (accessToken) {
        var decoded = verifyAccessToken(accessToken);
        if (decoded) {
            var users = req.app.locals.users;
            var user = users.get(decoded.email);
            if (user && !user.blocked) { req.user = user; }
        }
    }
    next();
}

module.exports = { generateTokens, verifyAccessToken, verifyRefreshToken, setCookie, clearCookie, authenticate, optionalAuth };
