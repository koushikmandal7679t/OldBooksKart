const fs = require('fs');
const path = require('path');

function globalErrorHandler(err, req, res, next) {
    const ip = req.ip || req.connection.remoteAddress;
    const errorLog = {
        timestamp: new Date().toISOString(),
        error: err.message,
        stack: err.stack,
        path: req.path,
        method: req.method,
        ip,
        userAgent: req.headers['user-agent']
    };

    fs.appendFile(
        path.join(__dirname, '..', 'logs', 'error.log'),
        JSON.stringify(errorLog) + '\n',
        () => {}
    );

    if (process.env.NODE_ENV === 'development') {
        return res.status(err.status || 500).json({
            success: false,
            message: err.message,
            stack: err.stack
        });
    }

    res.status(err.status || 500).json({
        success: false,
        message: 'An internal error occurred. Please try again later.'
    });
}

function notFoundHandler(req, res) {
    res.status(404).json({ success: false, message: 'Resource not found' });
}

module.exports = { globalErrorHandler, notFoundHandler };