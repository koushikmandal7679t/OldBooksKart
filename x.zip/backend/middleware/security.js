const fs = require('fs');
const path = require('path');

const SUSPICIOUS_PATTERNS = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|TRUNCATE)\b.*\b(FROM|INTO|TABLE|DATABASE|WHERE)\b)/i,
    /(OR\s+1\s*=\s*1)/i,
    /(OR\s+'[^']*'\s*=\s*'[^']*')/i,
    /(;\s*(DROP|DELETE|UPDATE|INSERT))/i,
    /(<\s*script[\s>])/i,
    /(javascript\s*:)/i,
    /(on\w+\s*=\s*['"])/i,
    /(\.\.\/|\.\.\\)/,
    /(`[^`]*`)/,
    /(\$\(.*\))/,
    /(<\s*iframe[\s>])/i,
    /(<\s*img[^>]+on\w+)/i,
    /(%3Cscript)/i,
    /(%27|%22)/i,
];

const BOT_USER_AGENTS = [
    'bot', 'crawl', 'spider', 'scraper', 'curl', 'wget', 'python-requests',
    'httpclient', 'java/', 'node-fetch', 'axios', 'postman', 'insomnia',
    'swagger', 'hoppscotch', 'brave', 'puppeteer', 'selenium', 'phantomjs'
];

function detectSuspiciousContent(str) {
    if (!str || typeof str !== 'string') return false;
    return SUSPICIOUS_PATTERNS.some(pattern => pattern.test(str));
}

function isBotUA(ua) {
    if (!ua) return true;
    const lower = ua.toLowerCase();
    return BOT_USER_AGENTS.some(bot => lower.includes(bot));
}

function securityCheck(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress;
    const ua = req.headers['user-agent'] || '';

    if (isBotUA(ua) && !req.path.includes('/api/auth/google')) {
        logSecurity('BOT_DETECTED', ip, { userAgent: ua, path: req.path });
        return res.status(403).json({ success: false, message: 'Request blocked' });
    }

    const checkFields = [
        req.body && JSON.stringify(req.body),
        req.query && JSON.stringify(req.query),
        req.params && JSON.stringify(req.params),
    ].filter(Boolean).join(' ');

    if (detectSuspiciousContent(checkFields)) {
        logSecurity('INJECTION_ATTEMPT', ip, {
            path: req.path,
            userAgent: ua,
            body: req.body
        });
        return res.status(403).json({ success: false, message: 'Malformed request' });
    }

    const origin = req.headers['origin'] || req.headers['referer'] || '';
    const clientUrl = process.env.CLIENT_URL || 'http://localhost:5000';
    if (origin && !origin.startsWith(clientUrl.replace(/\/$/, ''))) {
        logSecurity('CROSS_ORIGIN', ip, { origin, path: req.path });
    }

    req.fingerprint = `${ip}-${ua.slice(0, 50)}`;
    next();
}

function logSecurity(type, ip, details = {}) {
    const logEntry = {
        timestamp: new Date().toISOString(),
        type,
        ip,
        ...details
    };
    const logLine = JSON.stringify(logEntry) + '\n';
    fs.appendFile(path.join(__dirname, '..', 'logs', 'security.log'), logLine, () => {});
    return logEntry;
}

module.exports = { securityCheck, detectSuspiciousContent, isBotUA, logSecurity };