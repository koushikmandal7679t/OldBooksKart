const express = require('express');
const bcrypt = require('bcryptjs');
const { authenticate } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/admin');
const { logToFirebase } = require('../config/firebase');
const { logSecurity } = require('../middleware/security');

const router = express.Router();
router.use(authenticate, requireAdmin);

/* ===== STATS ===== */
router.get('/stats', (req, res) => {
    const users = req.app.locals.users;
    const userArray = Array.from(users.values());
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString();
    const monthAgo = new Date(now.getFullYear(), now.getMonth(), 0).toISOString();
    const yearAgo = new Date(now.getFullYear(), 0, 0).toISOString();

    const totalUsers = userArray.length;
    const activeUsers = userArray.filter(u => u.verified && !u.blocked).length;
    const blockedUsers = userArray.filter(u => u.blocked).length;
    const unverifiedUsers = userArray.filter(u => !u.verified).length;
    const totalLogins = userArray.reduce((s, u) => s + (u.loginCount || 0), 0);
    const todayLogins = userArray.filter(u => u.lastLogin && u.lastLogin >= today).length;
    const weekLogins = userArray.filter(u => u.lastLogin && u.lastLogin >= weekAgo).length;
    const todaySignups = userArray.filter(u => u.createdAt >= today).length;
    const weekSignups = userArray.filter(u => u.createdAt >= weekAgo).length;
    const monthSignups = userArray.filter(u => u.createdAt >= monthAgo).length;
    const yearSignups = userArray.filter(u => u.createdAt >= yearAgo).length;
    const googleUsers = userArray.filter(u => u.provider === 'google').length;
    const emailUsers = userArray.filter(u => u.provider === 'email').length;

    /* Daily logins — 30 days */
    const dailyLogins = [];
    for (let i = 29; i >= 0; i--) {
        const d = new Date(now - i * 24 * 60 * 60 * 1000);
        const dStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).toISOString();
        const dEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).toISOString();
        dailyLogins.push({
            date: d.toISOString().split('T')[0],
            count: userArray.filter(u => u.lastLogin && u.lastLogin >= dStart && u.lastLogin < dEnd).length
        });
    }

    /* Weekly signups — 12 weeks */
    const weeklySignups = [];
    for (let i = 11; i >= 0; i--) {
        const wEnd = new Date(now - i * 7 * 24 * 60 * 60 * 1000);
        const wStart = new Date(wEnd - 7 * 24 * 60 * 60 * 1000);
        weeklySignups.push({
            week: 'W' + (12 - i),
            count: userArray.filter(u => u.createdAt >= wStart.toISOString() && u.createdAt < wEnd.toISOString()).length
        });
    }

    /* Monthly signups — 12 months */
    const monthlySignups = [];
    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    for (let i = 11; i >= 0; i--) {
        const m = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const mEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
        monthlySignups.push({
            month: monthNames[m.getMonth()],
            count: userArray.filter(u => u.createdAt >= m.toISOString() && u.createdAt < mEnd.toISOString()).length
        });
    }

    res.json({
        success: true,
        stats: {
            totalUsers, activeUsers, blockedUsers, unverifiedUsers,
            totalLogins, todayLogins, weekLogins,
            todaySignups, weekSignups, monthSignups, yearSignups,
            googleUsers, emailUsers,
            dailyLogins, weeklySignups, monthlySignups,
            blockedIPs: Array.from(req.app.locals.blockedIPs),
            securityLogCount: req.app.locals.securityLogs.length
        }
    });
});

/* ===== USERS LIST ===== */
router.get('/users', (req, res) => {
    const users = req.app.locals.users;
    const userList = Array.from(users.values()).map(u => ({
        id: u.id,
        name: u.name,
        email: u.email,
        verified: u.verified,
        blocked: u.blocked,
        role: u.role,
        createdAt: u.createdAt,
        lastLogin: u.lastLogin,
        loginCount: u.loginCount,
        provider: u.provider || 'email'
    }));
    res.json({ success: true, users: userList });
});

/* ===== EDIT USER ===== */
router.put('/users/:id', (req, res) => {
    const { id } = req.params;
    const { name, email, role } = req.body;
    const users = req.app.locals.users;

    let user = null, userEmail = null;
    for (const [e, u] of users) {
        if (u.id === id) { user = u; userEmail = e; break; }
    }
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    if (name && name.trim().length >= 2) user.name = name.trim();
    if (role && ['user', 'admin'].includes(role)) user.role = role;

    if (email && email !== userEmail) {
        const GMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
        if (!GMAIL_REGEX.test(email)) return res.status(400).json({ success: false, message: 'Only Gmail allowed' });
        users.delete(userEmail);
        user.email = email.toLowerCase();
        userEmail = email.toLowerCase();
    }

    users.set(userEmail, user);
    req.app.locals.saveData();
    logToFirebase('admin_logs', { admin: req.user.email, action: 'edit_user', target: userEmail });
    res.json({ success: true, message: 'User updated', user });
});

/* ===== DELETE USER ===== */
router.delete('/users/:id', (req, res) => {
    const { id } = req.params;
    const users = req.app.locals.users;

    let targetEmail = null;
    for (const [e, u] of users) {
        if (u.id === id) { targetEmail = e; break; }
    }
    if (!targetEmail) return res.status(404).json({ success: false, message: 'User not found' });
    if (targetEmail === req.user.email) return res.status(400).json({ success: false, message: 'Cannot delete yourself' });

    users.delete(targetEmail);
    req.app.locals.saveData();
    logToFirebase('admin_logs', { admin: req.user.email, action: 'delete_user', target: targetEmail });
    res.json({ success: true, message: 'User deleted' });
});

/* ===== BLOCK / UNBLOCK ===== */
router.put('/users/:id/block', (req, res) => {
    const { id } = req.params;
    const users = req.app.locals.users;

    let user = null, userEmail = null;
    for (const [e, u] of users) {
        if (u.id === id) { user = u; userEmail = e; break; }
    }
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    if (userEmail === req.user.email) return res.status(400).json({ success: false, message: 'Cannot block yourself' });

    user.blocked = !user.blocked;
    users.set(userEmail, user);
    req.app.locals.saveData();
    logToFirebase('admin_logs', { admin: req.user.email, action: user.blocked ? 'block_user' : 'unblock_user', target: userEmail });
    res.json({ success: true, message: user.blocked ? 'User blocked' : 'User unblocked' });
});

/* ===== RESET PASSWORD ===== */
router.put('/users/:id/reset-password', async (req, res, next) => {
    try {
        const { id } = req.params;
        const { newPassword } = req.body;
        if (!newPassword || newPassword.length < 8) {
            return res.status(400).json({ success: false, message: 'Password must be at least 8 characters' });
        }

        const users = req.app.locals.users;
        let user = null, userEmail = null;
        for (const [e, u] of users) {
            if (u.id === id) { user = u; userEmail = e; break; }
        }
        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        user.password = await bcrypt.hash(newPassword, 12);
        users.set(userEmail, user);
        req.app.locals.saveData();
        logToFirebase('admin_logs', { admin: req.user.email, action: 'reset_password', target: userEmail });
        res.json({ success: true, message: 'Password reset successfully' });
    } catch (err) { next(err); }
});

/* ===== SITE SETTINGS ===== */
router.get('/site-settings', (req, res) => {
    res.json({ success: true, settings: req.app.locals.siteSettings });
});

router.put('/site-settings', (req, res) => {
    const { privacyPolicy, homepageTitle, homepageDescription, loginMessage, dashboardMessage } = req.body;
    const settings = req.app.locals.siteSettings;

    if (privacyPolicy !== undefined) settings.privacyPolicy = privacyPolicy;
    if (homepageTitle !== undefined) settings.homepageTitle = homepageTitle;
    if (homepageDescription !== undefined) settings.homepageDescription = homepageDescription;
    if (loginMessage !== undefined) settings.loginMessage = loginMessage;
    if (dashboardMessage !== undefined) settings.dashboardMessage = dashboardMessage;

    req.app.locals.siteSettings = settings;
    req.app.locals.saveData();
    logToFirebase('admin_logs', { admin: req.user.email, action: 'update_site_settings' });
    res.json({ success: true, message: 'Settings updated', settings });
});

/* ===== SECURITY LOGS ===== */
router.get('/security-logs', (req, res) => {
    const logs = req.app.locals.securityLogs.slice(-300).reverse();
    res.json({ success: true, logs });
});

/* ===== BLOCKED IPs ===== */
router.post('/blocked-ips', (req, res) => {
    const { ip, action } = req.body;
    if (!ip || typeof ip !== 'string') {
        return res.status(400).json({ success: false, message: 'IP required' });
    }

    if (action === 'block') {
        req.app.locals.blockedIPs.add(ip.trim());
        logSecurity('IP_BLOCKED_MANUAL', ip, { admin: req.user.email });
    } else if (action === 'unblock') {
        req.app.locals.blockedIPs.delete(ip.trim());
        logSecurity('IP_UNBLOCKED_MANUAL', ip, { admin: req.user.email });
    } else {
        return res.status(400).json({ success: false, message: 'Action must be block or unblock' });
    }

    req.app.locals.saveData();
    res.json({ success: true, blockedIPs: Array.from(req.app.locals.blockedIPs) });
});

module.exports = router;
