const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const passport = require('passport');
const { generateTokens, verifyRefreshToken, authenticate, setCookie, clearCookie } = require('../middleware/auth');
const { securityCheck, logSecurity } = require('../middleware/security');
const { logToFirebase } = require('../config/firebase');

const router = express.Router();

let resend = null;
const resendKey = process.env.RESEND_API_KEY;
if (resendKey && !resendKey.includes('xxx') && resendKey.startsWith('re_')) {
    try {
        const { Resend } = require('resend');
        resend = new Resend(resendKey);
        console.log('[Resend] Initialized');
    } catch (err) {
        console.log('[Resend] Failed to initialize:', err.message);
    }
} else {
    console.log('[Resend] No valid API key found. Email sending is disabled.');
}

const GMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;

const clientUrl = process.env.CLIENT_URL || 'http://localhost:3000';

/* Token expiry durations matching the JWT signing times */
const ACCESS_MS = 1 * 60 * 60 * 1000;       /* 1 hour */
const REFRESH_MS = 30 * 24 * 60 * 60 * 1000;  /* 30 days */

function validateEmail(email) {
    return GMAIL_REGEX.test(email);
}

function validatePassword(password) {
    return PASSWORD_REGEX.test(password);
}

function getPasswordErrors(password) {
    const errors = [];
    if (password.length < 8) errors.push('Minimum 8 characters');
    if (!/[A-Z]/.test(password)) errors.push('Uppercase letter required');
    if (!/[a-z]/.test(password)) errors.push('Lowercase letter required');
    if (!/\d/.test(password)) errors.push('Number required');
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) errors.push('Special character required');
    return errors;
}

function generateCaptcha() {
    const a = Math.floor(Math.random() * 15) + 1;
    const b = Math.floor(Math.random() * 15) + 1;
    return { question: `${a} + ${b} = ?`, answer: a + b };
}

/* ---------- Captcha ---------- */
router.get('/captcha', (req, res) => {
    const captcha = generateCaptcha();
    const captchaId = uuidv4();
    req.app.locals.captchas.set(captchaId, { answer: captcha.answer, expiresAt: Date.now() + 300000 });
    res.json({ success: true, captchaId, question: captcha.question });
});

/* ---------- Signup ---------- */
router.post('/signup', securityCheck, async (req, res, next) => {
    try {
        const { name, email, password, captchaId, captchaAnswer } = req.body;
        const ip = req.ip || req.connection.remoteAddress;

        if (!name || !email || !password) {
            return res.status(400).json({ success: false, message: 'All fields are required' });
        }

        if (!validateEmail(email)) {
            logSecurity('INVALID_EMAIL_DOMAIN', ip, { email });
            return res.status(400).json({ success: false, message: 'Only Gmail addresses are allowed' });
        }

        if (!validatePassword(password)) {
            return res.status(400).json({ success: false, message: 'Password does not meet requirements', errors: getPasswordErrors(password) });
        }

        const captcha = req.app.locals.captchas.get(captchaId);
        if (!captcha || captcha.expiresAt < Date.now()) {
            return res.status(400).json({ success: false, message: 'Captcha expired, please refresh' });
        }
        if (parseInt(captchaAnswer) !== captcha.answer) {
            req.app.locals.captchas.delete(captchaId);
            return res.status(400).json({ success: false, message: 'Incorrect captcha answer' });
        }
        req.app.locals.captchas.delete(captchaId);

        const users = req.app.locals.users;
        if (users.has(email)) {
            return res.status(409).json({ success: false, message: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 12);
        const verificationToken = uuidv4() + uuidv4();

        const user = {
            id: uuidv4(),
            name: name.trim(),
            email: email.toLowerCase(),
            password: hashedPassword,
            verified: false,
            blocked: false,
            role: 'user',
            createdAt: new Date().toISOString(),
            lastLogin: null,
            loginCount: 0,
            provider: 'email'
        };

        users.set(email, user);
        req.app.locals.verificationTokens.set(verificationToken, {
            email,
            expiresAt: Date.now() + 600000,
            used: false
        });
        req.app.locals.saveData();

        if (resend) {
            const verificationUrl = `${clientUrl}/verify-email.html?token=${verificationToken}`;
            try {
                await resend.emails.send({
                    from: process.env.EMAIL_FROM || 'noreply@oldbookskart.in',
                    to: email,
                    subject: 'Verify Your Email Address',
                    html: `
                        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                            <h2 style="color: #d4a843;">Email Verification</h2>
                            <p>Hello ${name},</p>
                            <p>Please click the link below to verify your email address. This link expires in 10 minutes.</p>
                            <a href="${verificationUrl}" style="display: inline-block; padding: 12px 24px; background: #d4a843; color: #000; text-decoration: none; border-radius: 6px; font-weight: 600;">Verify Email</a>
                            <p style="color: #888; font-size: 14px; margin-top: 20px;">If you did not create an account, please ignore this email.</p>
                        </div>
                    `
                });
            } catch (emailErr) {
                console.log('[Resend] Email send failed:', emailErr.message);
            }
        } else {
            console.log('[Resend] Skipped verification email for', email, '(no API key)');
        }

        logToFirebase('signup_logs', { email, name, ip, provider: 'email' });

        res.status(201).json({
            success: true,
            message: 'Account created. Please check your email to verify your account.'
        });
    } catch (err) {
        next(err);
    }
});

/* ---------- Login ---------- */
router.post('/login', securityCheck, async (req, res, next) => {
    try {
        const { email, password, captchaId, captchaAnswer } = req.body;
        const ip = req.ip || req.connection.remoteAddress;

        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password are required' });
        }

        if (!validateEmail(email)) {
            logSecurity('INVALID_EMAIL_LOGIN', ip, { email });
            return res.status(400).json({ success: false, message: 'Invalid email format' });
        }

        const captcha = req.app.locals.captchas.get(captchaId);
        if (!captcha || captcha.expiresAt < Date.now()) {
            return res.status(400).json({ success: false, message: 'Captcha expired, please refresh' });
        }
        if (parseInt(captchaAnswer) !== captcha.answer) {
            req.app.locals.captchas.delete(captchaId);
            logSecurity('CAPTCHA_FAIL', ip, { email });
            return res.status(400).json({ success: false, message: 'Incorrect captcha answer' });
        }
        req.app.locals.captchas.delete(captchaId);

        const users = req.app.locals.users;
        const user = users.get(email.toLowerCase());

        if (!user) {
            logSecurity('LOGIN_FAIL_USER_NOT_FOUND', ip, { email });
            logToFirebase('login_logs', { email, ip, success: false, reason: 'user_not_found' });
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        if (user.blocked) {
            logSecurity('LOGIN_BLOCKED_USER', ip, { email });
            return res.status(403).json({ success: false, message: 'Account is blocked' });
        }

        if (!user.verified) {
            return res.status(403).json({ success: false, message: 'Please verify your email first' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            logSecurity('LOGIN_FAIL_WRONG_PASSWORD', ip, { email });
            logToFirebase('login_logs', { email, ip, success: false, reason: 'wrong_password' });
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        user.lastLogin = new Date().toISOString();
        user.loginCount += 1;
        users.set(email, user);
        req.app.locals.saveData();

        const { accessToken, refreshToken } = generateTokens({
            id: user.id,
            email: user.email,
            role: user.role
        });

        req.app.locals.refreshTokens.set(refreshToken, {
            email: user.email,
            expiresAt: Date.now() + REFRESH_MS
        });

        setCookie(res, 'accessToken', accessToken, ACCESS_MS);
        setCookie(res, 'refreshToken', refreshToken, REFRESH_MS);

        logToFirebase('login_logs', { email, ip, success: true, provider: 'email' });
        logToFirebase('traffic', { email, ip, action: 'login' });

        res.json({
            success: true,
            message: 'Login successful',
            user: { id: user.id, name: user.name, email: user.email, role: user.role }
        });
    } catch (err) {
        next(err);
    }
});

/* ---------- Google OAuth ---------- */
router.get('/google', passport.authenticate('google', {
    scope: ['profile', 'email'],
    accessType: 'offline'
}));

router.get('/google/callback',
    passport.authenticate('google', { session: false, failureRedirect: `${clientUrl}/login.html?error=oauth_failed` }),
    (req, res) => {
        try {
            const ip = req.ip || req.connection.remoteAddress;
            const profile = req.user;
            const users = req.app.locals.users;
            let user = users.get(profile.email);

            if (!user) {
                user = {
                    id: uuidv4(),
                    name: profile.displayName || profile.name.givenName,
                    email: profile.email,
                    password: null,
                    verified: true,
                    blocked: false,
                    role: profile.email === process.env.ADMIN_EMAIL ? 'admin' : 'user',
                    createdAt: new Date().toISOString(),
                    lastLogin: new Date().toISOString(),
                    loginCount: 1,
                    provider: 'google'
                };
                users.set(profile.email, user);
                req.app.locals.saveData();
                logToFirebase('signup_logs', { email: profile.email, name: user.name, ip, provider: 'google' });
            } else {
                if (user.blocked) {
                    return res.redirect(`${clientUrl}/login.html?error=blocked`);
                }
                user.lastLogin = new Date().toISOString();
                user.loginCount += 1;
                users.set(profile.email, user);
                req.app.locals.saveData();
            }

            const { accessToken, refreshToken } = generateTokens({
                id: user.id,
                email: user.email,
                role: user.role
            });

            req.app.locals.refreshTokens.set(refreshToken, {
                email: user.email,
                expiresAt: Date.now() + REFRESH_MS
            });

            setCookie(res, 'accessToken', accessToken, ACCESS_MS);
            setCookie(res, 'refreshToken', refreshToken, REFRESH_MS);

            logToFirebase('login_logs', { email: profile.email, ip, success: true, provider: 'google' });
            logToFirebase('traffic', { email: profile.email, ip, action: 'login_google' });

            res.redirect(`${clientUrl}/dashboard.html`);
        } catch (err) {
            console.error('[OAuth Callback Error]', err);
            res.redirect(`${clientUrl}/login.html?error=server_error`);
        }
    }
);

/* ---------- Refresh Token ---------- */
router.post('/refresh', (req, res, next) => {
    try {
        const refreshToken = req.cookies?.refreshToken;
        if (!refreshToken) {
            return res.status(401).json({ success: false, message: 'No refresh token' });
        }

        const stored = req.app.locals.refreshTokens.get(refreshToken);
        if (!stored || stored.expiresAt < Date.now()) {
            req.app.locals.refreshTokens.delete(refreshToken);
            clearCookie(res, 'accessToken');
            clearCookie(res, 'refreshToken');
            return res.status(401).json({ success: false, message: 'Refresh token expired' });
        }

        const decoded = verifyRefreshToken(refreshToken);
        if (!decoded) {
            return res.status(401).json({ success: false, message: 'Invalid refresh token' });
        }

        const users = req.app.locals.users;
        const user = users.get(decoded.email);
        if (!user || user.blocked) {
            return res.status(401).json({ success: false, message: 'User not found or blocked' });
        }

        const { accessToken, refreshToken: newRefreshToken } = generateTokens({
            id: user.id,
            email: user.email,
            role: user.role
        });

        req.app.locals.refreshTokens.delete(refreshToken);
        req.app.locals.refreshTokens.set(newRefreshToken, {
            email: user.email,
            expiresAt: Date.now() + REFRESH_MS
        });

        setCookie(res, 'accessToken', accessToken, ACCESS_MS);
        setCookie(res, 'refreshToken', newRefreshToken, REFRESH_MS);

        res.json({ success: true, message: 'Token refreshed' });
    } catch (err) {
        next(err);
    }
});

/* ---------- Logout ---------- */
router.post('/logout', (req, res) => {
    const refreshToken = req.cookies?.refreshToken;
    if (refreshToken) {
        req.app.locals.refreshTokens.delete(refreshToken);
    }
    clearCookie(res, 'accessToken');
    clearCookie(res, 'refreshToken');
    res.json({ success: true, message: 'Logged out' });
});

/* ---------- Verify Email ---------- */
router.get('/verify-email/:token', async (req, res, next) => {
    try {
        const { token } = req.params;
        const tokens = req.app.locals.verificationTokens;
        const tokenData = tokens.get(token);

        if (!tokenData) {
            return res.status(400).json({ success: false, message: 'Invalid verification link' });
        }

        if (tokenData.used) {
            return res.status(400).json({ success: false, message: 'Link already used' });
        }

        if (tokenData.expiresAt < Date.now()) {
            tokens.delete(token);
            return res.status(400).json({ success: false, message: 'Verification link expired' });
        }

        const users = req.app.locals.users;
        const user = users.get(tokenData.email);
        if (!user) {
            return res.status(400).json({ success: false, message: 'User not found' });
        }

        user.verified = true;
        users.set(tokenData.email, user);
        tokens.delete(token);
        req.app.locals.saveData();

        logToFirebase('signup_logs', { email: tokenData.email, action: 'verified' });

        res.json({ success: true, message: 'Email verified successfully. You can now login.' });
    } catch (err) {
        next(err);
    }
});

/* ---------- Get Current User ---------- */
router.get('/me', authenticate, (req, res) => {
    res.json({
        success: true,
        user: {
            id: req.user.id,
            name: req.user.name,
            email: req.user.email,
            role: req.user.role,
            verified: req.user.verified,
            createdAt: req.user.createdAt,
            lastLogin: req.user.lastLogin,
            loginCount: req.user.loginCount
        }
    });
});

module.exports = router;
