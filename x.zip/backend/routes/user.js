const express = require('express');
const bcrypt = require('bcryptjs');
const { authenticate } = require('../middleware/auth');
const { logToFirebase } = require('../config/firebase');

const router = express.Router();

router.get('/profile', authenticate, (req, res) => {
    res.json({
        success: true,
        user: {
            id: req.user.id,
            name: req.user.name,
            email: req.user.email,
            role: req.user.role,
            verified: req.user.verified,
            createdAt: req.user.createdAt,
            lastLogin: req.user.lastLogin,
            loginCount: req.user.loginCount
        }
    });
});

router.put('/profile', authenticate, async (req, res, next) => {
    try {
        const { name } = req.body;
        if (!name || name.trim().length < 2) {
            return res.status(400).json({ success: false, message: 'Name must be at least 2 characters' });
        }

        const users = req.app.locals.users;
        const user = users.get(req.user.email);
        user.name = name.trim();
        users.set(req.user.email, user);
        req.app.locals.saveData();

        logToFirebase('activity_logs', { email: req.user.email, action: 'profile_update' });

        res.json({ success: true, message: 'Profile updated', user });
    } catch (err) {
        next(err);
    }
});

router.put('/change-password', authenticate, async (req, res, next) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ success: false, message: 'Both passwords are required' });
        }

        const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;
        if (!PASSWORD_REGEX.test(newPassword)) {
            return res.status(400).json({ success: false, message: 'New password does not meet requirements' });
        }

        const isMatch = await bcrypt.compare(currentPassword, req.user.password);
        if (!isMatch) {
            return res.status(401).json({ success: false, message: 'Current password is incorrect' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 12);
        const users = req.app.locals.users;
        const user = users.get(req.user.email);
        user.password = hashedPassword;
        users.set(req.user.email, user);
        req.app.locals.saveData();

        logToFirebase('activity_logs', { email: req.user.email, action: 'password_change' });

        res.json({ success: true, message: 'Password changed successfully' });
    } catch (err) {
        next(err);
    }
});

module.exports = router;