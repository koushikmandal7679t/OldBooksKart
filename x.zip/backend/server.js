require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const userRoutes = require('./routes/user');
const { securityCheck, logSecurity } = require('./middleware/security');
const { globalErrorHandler, notFoundHandler } = require('./middleware/errorHandler');
const { initFirebase, logToFirebase } = require('./config/firebase');

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_FILE = path.join(__dirname, 'data.json');

/*
 * URLs
 */
const clientUrl = process.env.CLIENT_URL || 'http://localhost:3000';
const apiUrl = process.env.API_URL || `http://localhost:${PORT}`;

/*
 * CORS
 */
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
}));

app.use(cors({
    origin: function (origin, callback) {
        callback(null, true);
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Set-Cookie']
}));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

/*
 * Rate limiters
 */
const loginLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    message: { success: false, message: 'Too many login attempts. Try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        const ip = req.ip || req.connection.remoteAddress;
        logSecurity('RATE_LIMIT_LOGIN', ip, { path: req.path });
        res.status(429).json({ success: false, message: 'Too many login attempts. Try again later.' });
    }
});

const registerLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 3,
    message: { success: false, message: 'Too many registration attempts. Try again later.' },
    standardHeaders: true,
    legacyHeaders: false
});

const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 60,
    message: { success: false, message: 'Too many requests.' },
    standardHeaders: true,
    legacyHeaders: false
});

const refreshLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    message: { success: false, message: 'Too many token refresh attempts.' },
    standardHeaders: true,
    legacyHeaders: false
});

/*
 * Data persistence
 */
function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
            return {
                users: new Map(data.users || []),
                blockedIPs: new Set(data.blockedIPs || []),
                siteSettings: data.siteSettings || {
                    privacyPolicy: 'Your privacy policy content goes here. Update it from the admin dashboard.',
                    homepageTitle: 'OldBooksKart',
                    homepageDescription: 'Your gateway to discovering rare and vintage books. A curated collection of literary treasures waiting to be explored.',
                    loginMessage: '',
                    dashboardMessage: ''
                },
                securityLogs: data.securityLogs || []
            };
        }
    } catch (err) {
        console.log('[Data] Load error:', err.message);
    }
    return {
        users: new Map(),
        blockedIPs: new Set(),
        siteSettings: {
            privacyPolicy: 'Your privacy policy content goes here. Update it from the admin dashboard.',
            homepageTitle: 'OldBooksKart',
            homepageDescription: 'Your gateway to discovering rare and vintage books. A curated collection of literary treasures waiting to be explored.',
            loginMessage: '',
            dashboardMessage: ''
        },
        securityLogs: []
    };
}

function saveDataToFile() {
    try {
        const data = {
            users: Array.from(app.locals.users.entries()),
            blockedIPs: Array.from(app.locals.blockedIPs),
            siteSettings: app.locals.siteSettings,
            securityLogs: app.locals.securityLogs
        };
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (err) {
        console.log('[Data] Save error:', err.message);
    }
}

function setupLocals() {
    const data = loadData();
    app.locals.users = data.users;
    app.locals.blockedIPs = data.blockedIPs;
    app.locals.siteSettings = data.siteSettings;
    app.locals.securityLogs = data.securityLogs;
    app.locals.captchas = new Map();
    app.locals.refreshTokens = new Map();
    app.locals.verificationTokens = new Map();
    app.locals.saveData = saveDataToFile;

    const originalLogSecurity = logSecurity;
    const wrappedLogSecurity = (type, ip, details) => {
        const entry = originalLogSecurity(type, ip, details);
        app.locals.securityLogs.push(entry);
        if (app.locals.securityLogs.length > 1000) {
            app.locals.securityLogs = app.locals.securityLogs.slice(-500);
        }
        return entry;
    };
    app.locals.logSecurity = wrappedLogSecurity;
}

async function seedAdmin() {
    const adminEmail = process.env.ADMIN_EMAIL;
    const adminPass = process.env.ADMIN_PASSWORD;
    if (!adminEmail || !adminPass) return;

    const users = app.locals.users;
    if (users.has(adminEmail)) return;

    const hashedPassword = await bcrypt.hash(adminPass, 12);
    users.set(adminEmail, {
        id: uuidv4(),
        name: 'Administrator',
        email: adminEmail,
        password: hashedPassword,
        verified: true,
        blocked: false,
        role: 'admin',
        createdAt: new Date().toISOString(),
        lastLogin: null,
        loginCount: 0,
        provider: 'email'
    });
    saveDataToFile();
    console.log('[Seed] Admin account created');
}

/*
 * IP block middleware
 */
function ipBlockMiddleware(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress;
    if (app.locals.blockedIPs.has(ip)) {
        return res.status(403).json({ success: false, message: 'Access denied' });
    }
    next();
}

/*
 * Access logger
 */
function accessLogger(req, res, next) {
    const start = Date.now();
    res.on('finish', () => {
        const logLine = `${new Date().toISOString()} ${req.ip} ${req.method} ${req.path} ${res.statusCode} ${Date.now() - start}ms\n`;
        fs.appendFile(path.join(__dirname, 'logs', 'access.log'), logLine, () => {});
    });
    next();
}

/*
 * Google OAuth — only initialize if real credentials exist.
 * Server starts fine without them; Google login just won't work.
 */
const googleClientId = process.env.GOOGLE_CLIENT_ID;
const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
const googleReady = googleClientId && googleClientSecret &&
    !googleClientId.includes('xxxx') && !googleClientSecret.includes('xxxx');

if (googleReady) {
    try {
        const passport = require('passport');
        const GoogleStrategy = require('passport-google-oauth20').Strategy;

        passport.use(new GoogleStrategy({
            clientID: googleClientId,
            clientSecret: googleClientSecret,
            callbackURL: `${apiUrl}/api/auth/google/callback`
        }, (accessToken, refreshToken, profile, done) => {
            if (!profile.emails || !profile.emails[0]) {
                return done(new Error('No email in Google profile'), null);
            }
            const email = profile.emails[0].value;
            if (!email.endsWith('@gmail.com')) {
                return done(new Error('Only Gmail accounts are allowed'), null);
            }
            done(null, profile);
        }));

        passport.serializeUser((user, done) => done(null, user));
        passport.deserializeUser((user, done) => done(null, user));

        /* Initialize Passport for OAuth routes only */
        app.use('/api/auth/google', passport.initialize());

        console.log('[Google OAuth] Initialized');
    } catch (err) {
        console.log('[Google OAuth] Failed to initialize:', err.message);
    }
} else {
    console.log('[Google OAuth] No credentials found. Google login is disabled.');
}

/*
 * Initialize
 */
initFirebase();
setupLocals();
seedAdmin();

/*
 * Middleware pipeline
 */
app.use(accessLogger);
app.use(ipBlockMiddleware);
app.use(securityCheck);

app.use('/api/auth/login', loginLimiter);
app.use('/api/auth/signup', registerLimiter);
app.use('/api/auth/refresh', refreshLimiter);
app.use('/api/', apiLimiter);

/*
 * API routes
 */
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/user', userRoutes);
app.get('/api/site-settings', (req, res) => {
    res.json({ success: true, settings: app.locals.siteSettings });
});

/*
 * Health check
 */
app.get('/api/health', (req, res) => {
    res.json({ success: true, timestamp: new Date().toISOString() });
});

/*
 * 404 — API returns JSON, no HTML
 */
app.use('/api', notFoundHandler);
app.use((req, res) => {
    res.status(404).json({ success: false, message: 'Not found. This is an API server.' });
});

app.use(globalErrorHandler);

/*
 * Ensure log directories exist
 */
if (!fs.existsSync(path.join(__dirname, 'logs'))) {
    fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true });
}
if (!fs.existsSync(path.join(__dirname, 'logs', 'error.log'))) {
    fs.writeFileSync(path.join(__dirname, 'logs', 'error.log'), '');
}
if (!fs.existsSync(path.join(__dirname, 'logs', 'access.log'))) {
    fs.writeFileSync(path.join(__dirname, 'logs', 'access.log'), '');
}

app.listen(PORT, () => {
    console.log('========================================');
    console.log('  API Server Started');
    console.log(`  Port:      ${PORT}`);
    console.log(`  API URL:   ${apiUrl}`);
    console.log(`  Client:    ${clientUrl}`);
    console.log(`  Env:       ${process.env.NODE_ENV || 'development'}`);
    console.log('========================================');
});
