const API_URL = 'http://localhost:5000';
let adminToken = null;
let userGrowthChart = null;
let loginActivityChart = null;

document.addEventListener('DOMContentLoaded', () => {
    setupAdminLogin();
    loadFloatingMessages('admin');
});

function setupAdminLogin() {
    const token = localStorage.getItem('adminToken');
    if (token) {
        adminToken = token;
        document.getElementById('adminLoginContainer').style.display = 'none';
        document.getElementById('adminDashboard').style.display = 'flex';
        loadAdminDashboard();
    }
    
    const form = document.getElementById('adminLoginForm');
    if (form) {
        form.addEventListener('submit', handleAdminLogin);
    }
}

async function handleAdminLogin(e) {
    e.preventDefault();
    const email = document.getElementById('adminEmail').value;
    const password = document.getElementById('adminPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.token) {
            adminToken = data.token;
            localStorage.setItem('adminToken', adminToken);
            document.getElementById('adminLoginContainer').style.display = 'none';
            document.getElementById('adminDashboard').style.display = 'flex';
            loadAdminDashboard();
            showFloatingMessage('Welcome to Admin Console', 'success');
        } else {
            showFloatingMessage('Invalid credentials', 'error');
        }
    } catch (error) {
        showFloatingMessage('Login failed', 'error');
    }
}

async function loadAdminDashboard() {
    await loadAdminStats();
    await loadUsers();
    await loadTraffic('all');
    await loadMessages();
    await loadPrivacyPolicy();
    await loadAnnouncements();
    await loadLogs();
    setupAdminCharts();
    setupAdminNavigation();
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);
}

function updateCurrentTime() {
    const timeElement = document.getElementById('currentTime');
    if (timeElement) {
        timeElement.innerText = new Date().toLocaleString();
    }
}

async function loadAdminStats() {
    try {
        const response = await fetch(`${API_URL}/admin/stats`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        const stats = await response.json();
        
        const statsGrid = document.getElementById('adminStatsGrid');
        statsGrid.innerHTML = `
            <div class="stat-card"><h4>Total Users</h4><div class="stat-value">${stats.totalUsers}</div></div>
            <div class="stat-card"><h4>Active Users</h4><div class="stat-value">${stats.activeUsers}</div></div>
            <div class="stat-card"><h4>Banned Users</h4><div class="stat-value">${stats.bannedUsers}</div></div>
            <div class="stat-card"><h4>Today's Logins</h4><div class="stat-value">${stats.todayLogins}</div></div>
            <div class="stat-card"><h4>Week Logins</h4><div class="stat-value">${stats.weekLogins}</div></div>
            <div class="stat-card"><h4>Month Logins</h4><div class="stat-value">${stats.monthLogins}</div></div>
        `;
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadUsers() {
    try {
        const response = await fetch(`${API_URL}/admin/users`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        const users = await response.json();
        
        const tbody = document.getElementById('usersTableBody');
        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${escapeHtml(user.email)}</td>
                <td><span style="background: #e2e8f0; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem;">${user.loginType}</span></td>
                <td><span class="status-badge" style="background: ${user.status === 'active' ? '#10b981' : '#ef4444'}; color: white; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem;">${user.status}</span></td>
                <td>${new Date(user.createdAt).toLocaleDateString()}</td>
                <td>
                    <button class="action-btn ${user.status === 'active' ? 'block' : 'edit'}" onclick="toggleUserStatus('${user.id}', '${user.status}')">
                        ${user.status === 'active' ? 'Block' : 'Unblock'}
                    </button>
                    <button class="action-btn delete" onclick="deleteUser('${user.id}')">Delete</button>
                </td>
            </table>
        `).join('');
        
        const searchInput = document.getElementById('userSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                const rows = tbody.querySelectorAll('tr');
                rows.forEach(row => {
                    const email = row.cells[0].innerText.toLowerCase();
                    row.style.display = email.includes(searchTerm) ? '' : 'none';
                });
            });
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

async function loadTraffic(filter = 'all') {
    try {
        const response = await fetch(`${API_URL}/admin/traffic?filter=${filter}`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        const traffic = await response.json();
        
        const tbody = document.getElementById('trafficTableBody');
        tbody.innerHTML = traffic.slice(0, 100).map(log => `
            <tr>
                <td>${escapeHtml(log.email)}</td>
                <td>${new Date(log.time).toLocaleString()}</td>
                <td><span style="background: #e2e8f0; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem;">${log.type || 'email'}</span></td>
                <td>${log.ip || 'N/A'}</td>
            </tr>
        `).join('');
        
        const trafficFilter = document.getElementById('trafficFilter');
        if (trafficFilter) {
            trafficFilter.addEventListener('change', (e) => {
                loadTraffic(e.target.value);
            });
        }
    } catch (error) {
        console.error('Failed to load traffic:', error);
    }
}

async function loadMessages() {
    try {
        const response = await fetch(`${API_URL}/api/floating-messages`);
        const messages = await response.json();
        
        const container = document.getElementById('messagesList');
        container.innerHTML = messages.map(msg => `
            <div class="message-item">
                <div>
                    <strong>${escapeHtml(msg.text)}</strong>
                    <div style="margin-top: 4px;">
                        <span style="background: #e2e8f0; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;">${msg.type}</span>
                        <span style="background: #e2e8f0; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; margin-left: 8px;">${msg.page}</span>
                        <span style="color: ${msg.active ? '#10b981' : '#ef4444'}; margin-left: 8px; font-size: 0.75rem;">${msg.active ? 'Active' : 'Inactive'}</span>
                    </div>
                </div>
                <div>
                    <button class="action-btn edit" onclick="toggleMessageStatus('${msg.id}', ${!msg.active})">
                        ${msg.active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button class="action-btn delete" onclick="deleteMessage('${msg.id}')">Delete</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load messages:', error);
    }
}

async function loadPrivacyPolicy() {
    try {
        const response = await fetch(`${API_URL}/api/privacy-policy`);
        const data = await response.json();
        document.getElementById('privacyEditor').value = data.content;
    } catch (error) {
        console.error('Failed to load privacy policy:', error);
    }
}

async function savePrivacyPolicy() {
    const content = document.getElementById('privacyEditor').value;
    try {
        await fetch(`${API_URL}/admin/privacy-policy`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            },
            body: JSON.stringify({ content })
        });
        showFloatingMessage('Privacy policy updated successfully', 'success');
    } catch (error) {
        showFloatingMessage('Failed to update privacy policy', 'error');
    }
}

async function loadAnnouncements() {
    try {
        const response = await fetch(`${API_URL}/api/announcements`);
        const announcements = await response.json();
        
        const container = document.getElementById('announcementsList');
        container.innerHTML = announcements.map(ann => `
            <div class="announcement-item">
                <div>
                    <strong>${escapeHtml(ann.title)}</strong>
                    <p style="margin-top: 4px; color: #64748b; font-size: 0.875rem;">${escapeHtml(ann.content)}</p>
                    <span style="background: #e2e8f0; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem;">${ann.type}</span>
                </div>
                <div>
                    <button class="action-btn delete" onclick="deleteAnnouncement('${ann.id}')">Delete</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load announcements:', error);
    }
}

async function loadLogs() {
    try {
        const response = await fetch(`${API_URL}/admin/logs`, {
            headers: { 'Authorization': `Bearer ${adminToken}` }
        });
        const logs = await response.json();
        
        const container = document.getElementById('logsContainer');
        container.innerHTML = logs.map(log => `
            <div style="padding: 8px 0; border-bottom: 1px solid #334155; font-family: monospace;">
                [${new Date(log.time).toLocaleString()}] ${log.action} ${log.details ? '- ' + log.details : ''}
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load logs:', error);
    }
}

function setupAdminCharts() {
    const ctx1 = document.getElementById('userGrowthChart')?.getContext('2d');
    if (ctx1) {
        userGrowthChart = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'New Users',
                    data: [45, 62, 78, 94],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
    
    const ctx2 = document.getElementById('loginActivityChart')?.getContext('2d');
    if (ctx2) {
        loginActivityChart = new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                datasets: [{
                    label: 'Logins',
                    data: [124, 138, 142, 156, 168, 145, 98],
                    backgroundColor: '#3b82f6',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
}

function setupAdminNavigation() {
    document.querySelectorAll('[data-admin-page]').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.adminPage;
            
            document.querySelectorAll('[data-admin-page]').forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
            document.getElementById(`admin${capitalize(page)}Page`).classList.add('active');
            
            const titleElement = document.getElementById('adminPageTitle');
            if (titleElement) {
                titleElement.innerText = item.querySelector('span:last-child').innerText;
            }
        });
    });
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

async function toggleUserStatus(userId, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'banned' : 'active';
    const action = newStatus === 'active' ? 'unblocked' : 'blocked';
    
    if (confirm(`Are you sure you want to ${action} this user?`)) {
        try {
            await fetch(`${API_URL}/admin/users/${userId}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${adminToken}`
                },
                body: JSON.stringify({ status: newStatus })
            });
            showFloatingMessage(`User ${action} successfully`, 'success');
            loadUsers();
            loadAdminStats();
        } catch (error) {
            showFloatingMessage('Failed to update user status', 'error');
        }
    }
}

async function deleteUser(userId) {
    if (confirm('WARNING: This will permanently delete the user and all their data. This action cannot be undone. Continue?')) {
        try {
            await fetch(`${API_URL}/admin/users/${userId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${adminToken}` }
            });
            showFloatingMessage('User deleted successfully', 'success');
            loadUsers();
            loadAdminStats();
        } catch (error) {
            showFloatingMessage('Failed to delete user', 'error');
        }
    }
}

function showAddMessageModal() {
    const modal = document.getElementById('addMessageModal');
    modal.style.display = 'block';
    
    const closeBtn = modal.querySelector('.close');
    closeBtn.onclick = () => modal.style.display = 'none';
    
    const form = document.getElementById('addMessageForm');
    form.onsubmit = async (e) => {
        e.preventDefault();
        const text = document.getElementById('messageText').value;
        const type = document.getElementById('messageType').value;
        const duration = parseInt(document.getElementById('messageDuration').value);
        const page = document.getElementById('messagePage').value;
        
        try {
            await fetch(`${API_URL}/admin/floating-messages`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${adminToken}`
                },
                body: JSON.stringify({ text, type, duration, page })
            });
            showFloatingMessage('Message created successfully', 'success');
            modal.style.display = 'none';
            form.reset();
            loadMessages();
        } catch (error) {
            showFloatingMessage('Failed to create message', 'error');
        }
    };
}

async function toggleMessageStatus(id, active) {
    try {
        await fetch(`${API_URL}/admin/floating-messages/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${adminToken}`
            },
            body: JSON.stringify({ active })
        });
        showFloatingMessage(`Message ${active ? 'activated' : 'deactivated'}`, 'success');
        loadMessages();
    } catch (error) {
        showFloatingMessage('Failed to update message', 'error');
    }
}

async function deleteMessage(id) {
    if (confirm('Delete this message?')) {
        try {
            await fetch(`${API_URL}/admin/floating-messages/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${adminToken}` }
            });
            showFloatingMessage('Message deleted', 'success');
            loadMessages();
        } catch (error) {
            showFloatingMessage('Failed to delete message', 'error');
        }
    }
}

function showAddAnnouncementModal() {
    const modal = document.getElementById('addAnnouncementModal');
    modal.style.display = 'block';
    
    const closeBtn = modal.querySelector('.close');
    closeBtn.onclick = () => modal.style.display = 'none';
    
    const form = document.getElementById('addAnnouncementForm');
    form.onsubmit = async (e) => {
        e.preventDefault();
        const title = document.getElementById('announcementTitle').value;
        const content = document.getElementById('announcementContent').value;
        const type = document.getElementById('announcementType').value;
        
        try {
            await fetch(`${API_URL}/admin/announcements`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${adminToken}`
                },
                body: JSON.stringify({ title, content, type })
            });
            showFloatingMessage('Announcement published', 'success');
            modal.style.display = 'none';
            form.reset();
            loadAnnouncements();
        } catch (error) {
            showFloatingMessage('Failed to publish announcement', 'error');
        }
    };
}

async function deleteAnnouncement(id) {
    if (confirm('Delete this announcement?')) {
        try {
            await fetch(`${API_URL}/admin/announcements/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${adminToken}` }
            });
            showFloatingMessage('Announcement deleted', 'success');
            loadAnnouncements();
        } catch (error) {
            showFloatingMessage('Failed to delete announcement', 'error');
        }
    }
}

function refreshLogs() {
    loadLogs();
}

function adminLogout() {
    localStorage.removeItem('adminToken');
    adminToken = null;
    document.getElementById('adminLoginContainer').style.display = 'flex';
    document.getElementById('adminDashboard').style.display = 'none';
    showFloatingMessage('Logged out successfully', 'success');
}

function showFloatingMessage(text, type = 'info', duration = 5000) {
    const container = document.getElementById('floatingMessages');
    const message = document.createElement('div');
    message.className = `floating-message ${type}`;
    
    let icon = '';
    if (type === 'success') icon = '✓';
    else if (type === 'error') icon = '✗';
    else if (type === 'warning') icon = '!';
    else icon = 'i';
    
    message.innerHTML = `<span style="font-weight: 700;">${icon}</span><span>${text}</span>`;
    
    container.appendChild(message);
    
    setTimeout(() => {
        message.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => message.remove(), 300);
    }, duration);
}

async function loadFloatingMessages(page) {
    try {
        const response = await fetch(`${API_URL}/api/floating-messages`);
        const messages = await response.json();
        const activeMessages = messages.filter(m => m.active && (m.page === 'all' || m.page === page));
        activeMessages.forEach(msg => {
            setTimeout(() => showFloatingMessage(msg.text, msg.type, msg.duration), 500);
        });
    } catch (error) {
        console.error('Failed to load m
essages:', error);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
