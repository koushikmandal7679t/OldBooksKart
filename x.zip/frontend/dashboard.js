const API_URL = 'http://localhost:5000';
let currentUser = null;
let activityChart = null;
let categoryChart = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadFloatingMessages('dashboard');
    setupDashboard();
});

async function checkAuth() {
    const token = localStorage.getItem('token') || getCookie('token');
    if (!token) {
        window.location.href = 'index.html';
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/user`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (!response.ok) {
            throw new Error('Not authenticated');
        }
        
        currentUser = await response.json();
        document.getElementById('userEmail').innerText = currentUser.email;
        document.getElementById('userAvatar').innerText = currentUser.email.charAt(0).toUpperCase();
        document.getElementById('profileEmail').value = currentUser.email;
        if (currentUser.name) document.getElementById('profileName').value = currentUser.name;
        if (currentUser.phone) document.getElementById('profilePhone').value = currentUser.phone;
        if (currentUser.address) document.getElementById('profileAddress').value = currentUser.address;
        
        loadDashboardData();
    } catch (error) {
        localStorage.removeItem('token');
        window.location.href = 'index.html';
    }
}

async function loadDashboardData() {
    await loadStats();
    await loadBooks();
    await loadOrders();
    await loadRecentActivity();
    setupCharts();
    setupNavigation();
}

async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/api/user/books`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        const books = await response.json();
        
        const ordersResponse = await fetch(`${API_URL}/api/user/orders`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        const orders = await ordersResponse.json();
        
        const totalEarnings = orders.reduce((sum, order) => sum + (order.amount || 0), 0);
        
        const statsGrid = document.getElementById('statsGrid');
        statsGrid.innerHTML = `
            <div class="stat-card"><h4>Total Books</h4><div class="stat-value">${books.length}</div></div>
            <div class="stat-card"><h4>Orders</h4><div class="stat-value">${orders.length}</div></div>
            <div class="stat-card"><h4>Earnings</h4><div class="stat-value">₹${totalEarnings}</div></div>
            <div class="stat-card"><h4>Member Since</h4><div class="stat-value">${new Date(currentUser.createdAt).getFullYear()}</div></div>
        `;
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadBooks() {
    try {
        const response = await fetch(`${API_URL}/api/user/books`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        const books = await response.json();
        
        const booksList = document.getElementById('booksList');
        if (books.length === 0) {
            booksList.innerHTML = '<div class="empty-state">No books listed yet. Click "Add New Book" to get started.</div>';
            return;
        }
        
        booksList.innerHTML = books.map(book => `
            <div class="book-card">
                <h3>${escapeHtml(book.title)}</h3>
                <p style="color: #64748b; margin-bottom: 8px;">By ${escapeHtml(book.author)}</p>
                <p style="font-size: 1.25rem; font-weight: 700; color: #1e3c72; margin: 12px 0;">₹${book.price}</p>
                <p style="font-size: 0.875rem; color: #475569;">Condition: ${book.condition}</p>
                <p style="font-size: 0.875rem; color: #64748b; margin-top: 8px;">Status: ${book.status}</p>
                <button class="btn btn-outline" style="margin-top: 12px; width: 100%;" onclick="deleteBook('${book.id}')">Remove Listing</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load books:', error);
    }
}

async function loadOrders() {
    try {
        const response = await fetch(`${API_URL}/api/user/orders`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        const orders = await response.json();
        
        const ordersList = document.getElementById('ordersList');
        if (orders.length === 0) {
            ordersList.innerHTML = '<div class="empty-state">No orders yet. Start selling your books!</div>';
            return;
        }
        
        ordersList.innerHTML = orders.map(order => `
            <div class="order-card" style="background: white; padding: 1rem; border-radius: 12px; margin-bottom: 1rem; border: 1px solid #e2e8f0;">
                <div style="display: flex; justify-content: space-between;">
                    <div><strong>Order #${order.id.slice(0, 8)}</strong></div>
                    <div style="color: #10b981;">₹${order.amount}</div>
                </div>
                <div style="font-size: 0.875rem; color: #64748b; margin-top: 8px;">${new Date(order.createdAt).toLocaleDateString()}</div>
                <div style="font-size: 0.875rem; margin-top: 8px;">Status: ${order.status}</div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load orders:', error);
    }
}

async function loadRecentActivity() {
    const activityList = document.getElementById('recentActivity');
    activityList.innerHTML = '<div class="activity-item">Welcome to OldBooksKart! Start listing your books today.</div>';
}

function setupCharts() {
    const ctx1 = document.getElementById('activityChart')?.getContext('2d');
    if (ctx1) {
        activityChart = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                datasets: [{
                    label: 'Profile Views',
                    data: [42, 58, 65, 48, 72, 85, 64],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.05)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
    
    const ctx2 = document.getElementById('categoryChart')?.getContext('2d');
    if (ctx2) {
        categoryChart = new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: ['Fiction', 'Non-Fiction', 'Academic', 'Children'],
                datasets: [{
                    data: [35, 25, 30, 10],
                    backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444']
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
}

function setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            document.querySelectorAll('.dashboard-page').forEach(p => p.classList.remove('active'));
            document.getElementById(`${page}Page`).classList.add('active');
        });
    });
    
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
        });
    }
}

function showAddBookModal() {
    const modal = document.getElementById('addBookModal');
    modal.style.display = 'block';
    
    const closeBtn = modal.querySelector('.close');
    closeBtn.onclick = () => modal.style.display = 'none';
    
    const form = document.getElementById('addBookForm');
    form.onsubmit = async (e) => {
        e.preventDefault();
        
        const bookData = {
            title: document.getElementById('bookTitle').value,
            author: document.getElementById('bookAuthor').value,
            category: document.getElementById('bookCategory').value,
            price: parseInt(document.getElementById('bookPrice').value),
            condition: document.getElementById('bookCondition').value,
            description: document.getElementById('bookDescription').value
        };
        
        try {
            const response = await fetch(`${API_URL}/api/user/books`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(bookData)
            });
            
            const data = await response.json();
            if (data.success) {
                showFloatingMessage('Book listed successfully!', 'success');
                modal.style.display = 'none';
                form.reset();
                loadBooks();
                loadStats();
            } else {
                showFloatingMessage('Failed to list book', 'error');
            }
        } catch (error) {
            showFloatingMessage('Network error', 'error');
        }
    };
}

async function deleteBook(bookId) {
    if (confirm('Are you sure you want to remove this book listing?')) {
        try {
            const response = await fetch(`${API_URL}/api/user/books/${bookId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
            });
            
            const data = await response.json();
            if (data.success) {
                showFloatingMessage('Book removed successfully', 'success');
                loadBooks();
                loadStats();
            } else {
                showFloatingMessage('Failed to remove book', 'error');
            }
        } catch (error) {
            showFloatingMessage('Network error', 'error');
        }
    }
}

async function updateProfile() {
    const profileData = {
        name: document.getElementById('profileName').value,
        phone: document.getElementById('profilePhone').value,
        address: document.getElementById('profileAddress').value
    };
    
    try {
        const response = await fetch(`${API_URL}/api/user/profile`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(profileData)
        });
        
        const data = await response.json();
        if (data.success) {
            showFloatingMessage('Profile updated successfully', 'success');
        } else {
            showFloatingMessage('Failed to update profile', 'error');
        }
    } catch (error) {
        showFloatingMessage('Network error', 'error');
    }
}

async function changePassword() {
    const current = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirm = document.getElementById('confirmPassword').value;
    
    if (!current || !newPass || !confirm) {
        showFloatingMessage('Please fill all password fields', 'warning');
        return;
    }
    
    if (newPass !== confirm) {
        showFloatingMessage('New passwords do not match', 'error');
        return;
    }
    
    if (newPass.length < 8) {
        showFloatingMessage('Password must be at least 8 characters', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/user/change-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ currentPassword: current, newPassword: newPass })
        });
        
        const data = await response.json();
        if (data.success) {
            showFloatingMessage('Password changed successfully', 'success');
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        } else if (data.error) {
            showFloatingMessage(data.error, 'error');
        } else {
            showFloatingMessage('Failed to change password', 'error');
        }
    } catch (error) {
        showFloatingMessage('Network error', 'error');
    }
}

function logout() {
    localStorage.removeItem('token');
    document.cookie = 'token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    window.location.href = 'index.html';
}

function showFloatingMessage(text, type = 'info', duration = 5000) {
    const container = document.getElementById('floatingMessages');
    const message = document.createElement('div');
    message.className = `floating-message ${type}`;
    
    let icon = '';
    if (type === 'success') icon = '✓';
    else if (type === 'error') icon = '✗';
    else if (type === 'warning') icon = '!';
    else icon = 'i';
    
    message.innerHTML = `<span style="font-weight: 700;">${icon}</span><span>${text}</span>`;
    
    container.appendChild(message);
    
    setTimeout(() => {
        message.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => message.remove(), 300);
    }, duration);
}

async function loadFloatingMessages(page) {
    try {
        const response = await fetch(`${API_URL}/api/floating-messages`);
        const messages = await response.json();
        const activeMessages = messages.filter(m => m.active && (m.page === 'all' || m.page === page));
        activeMessages.forEach(msg => {
            setTimeout(() => showFloatingMessage(msg.text, msg.type, msg.duration), 500);
        });
    } catch (error) {
        console.error('Failed to load messages:', error);
    }
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
