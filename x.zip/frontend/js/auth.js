var AuthPage = {
    captchaId: null,

    initLogin: function () {
        this.loadCaptcha();
        this.loadFloatingMessage('login');
        this.setupPasswordToggle();

        document.getElementById('loginForm').addEventListener('submit', this.handleLogin.bind(this));
        document.getElementById('captchaRefresh').addEventListener('click', this.loadCaptcha.bind(this));

        var params = new URLSearchParams(window.location.search);
        var error = params.get('error');
        if (error) {
            var messages = {
                oauth_failed: 'Google authentication failed. Please try again.',
                blocked: 'Your account has been blocked.',
                server_error: 'An error occurred during authentication.'
            };
            Toast.error(messages[error] || 'Authentication error');
            window.history.replaceState({}, '', window.location.pathname);
        }
    },

    initSignup: function () {
        this.loadCaptcha();
        this.setupPasswordToggle();
        this.setupPasswordRequirements();

        document.getElementById('signupForm').addEventListener('submit', this.handleSignup.bind(this));
        document.getElementById('captchaRefresh').addEventListener('click', this.loadCaptcha.bind(this));
    },

    initVerifyEmail: function () {
        var token = new URLSearchParams(window.location.search).get('token');
        if (!token) {
            this.showVerifyResult('error', 'Invalid Link', 'The verification link is malformed.');
            return;
        }
        var self = this;
        API.get('/api/auth/verify-email/' + token)
            .then(function (data) {
                if (data.success) {
                    self.showVerifyResult('success', 'Email Verified', data.message);
                } else {
                    self.showVerifyResult('error', 'Verification Failed', data.message);
                }
            })
            .catch(function () {
                self.showVerifyResult('error', 'Network Error', 'Could not reach the server. Please try again.');
            });
    },

    showVerifyResult: function (type, title, message) {
        var icon = document.getElementById('verifyIcon');
        var titleEl = document.getElementById('verifyTitle');
        var msgEl = document.getElementById('verifyMessage');
        var actions = document.getElementById('verifyActions');

        icon.className = 'verify-icon ' + type;
        icon.innerHTML = type === 'success'
            ? '<i class="fas fa-circle-check"></i>'
            : '<i class="fas fa-circle-xmark"></i>';
        titleEl.textContent = title;
        msgEl.textContent = message;
        actions.style.display = 'block';
    },

    /* ---------- Captcha ---------- */
    loadCaptcha: function () {
        var self = this;
        fetch(API_BASE + '/api/auth/captcha')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    self.captchaId = data.captchaId;
                    document.getElementById('captchaQuestion').textContent = data.question;
                    var answerInput = document.getElementById('captchaAnswer');
                    if (answerInput) answerInput.value = '';
                    self.clearError('captchaError');
                }
            })
            .catch(function () {
                Toast.error('Failed to load captcha');
            });
    },

    /* ---------- Password Toggle ---------- */
    setupPasswordToggle: function () {
        document.querySelectorAll('.toggle-password').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = btn.parentElement.querySelector('input');
                var icon = btn.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    input.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
        });
    },

    /* ---------- Password Requirements ---------- */
    setupPasswordRequirements: function () {
        var passwordInput = document.getElementById('password');
        if (!passwordInput) return;

        passwordInput.addEventListener('input', function () {
            var val = passwordInput.value;
            var checks = {
                length: val.length >= 8,
                upper: /[A-Z]/.test(val),
                lower: /[a-z]/.test(val),
                number: /\d/.test(val),
                special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)
            };
            Object.keys(checks).forEach(function (key) {
                var item = document.querySelector('.req-item[data-req="' + key + '"]');
                if (item) item.classList.toggle('met', checks[key]);
            });
        });
    },

    /* ---------- Validation ---------- */
    validateEmail: function (email) {
        return /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(email.trim());
    },

    showError: function (id, msg) {
        var el = document.getElementById(id);
        if (el) el.textContent = msg;
    },

    clearError: function (id) {
        var el = document.getElementById(id);
        if (el) el.textContent = '';
    },

    clearAllErrors: function () {
        document.querySelectorAll('.field-error').forEach(function (el) { el.textContent = ''; });
    },

    /* ---------- Login ---------- */
    handleLogin: function (e) {
        e.preventDefault();
        this.clearAllErrors();
        var self = this;

        var email = document.getElementById('email').value.trim();
        var password = document.getElementById('password').value;
        var captchaAnswer = document.getElementById('captchaAnswer').value.trim();
        var valid = true;

        if (!email) { this.showError('emailError', 'Email is required'); valid = false; }
        else if (!this.validateEmail(email)) { this.showError('emailError', 'Only Gmail addresses are allowed'); valid = false; }

        if (!password) { this.showError('passwordError', 'Password is required'); valid = false; }
        else if (password.length < 8) { this.showError('passwordError', 'Password must be at least 8 characters'); valid = false; }

        if (!captchaAnswer) { this.showError('captchaError', 'Please answer the security question'); valid = false; }
        if (!valid) return;

        var btn = document.getElementById('loginBtn');
        btn.querySelector('.btn-text').style.display = 'none';
        btn.querySelector('.btn-loader').style.display = 'inline-flex';
        btn.disabled = true;

        API.post('/api/auth/login', {
            email: email,
            password: password,
            captchaId: self.captchaId,
            captchaAnswer: parseInt(captchaAnswer)
        }).then(function (result) {
            btn.querySelector('.btn-text').style.display = 'inline-flex';
            btn.querySelector('.btn-loader').style.display = 'none';
            btn.disabled = false;

            if (result.success) {
                Toast.success('Login successful');
                setTimeout(function () { window.location.href = '/dashboard.html'; }, 500);
            } else {
                Toast.error(result.message);
                self.loadCaptcha();
            }
        });
    },

    /* ---------- Signup ---------- */
    handleSignup: function (e) {
        e.preventDefault();
        this.clearAllErrors();
        var self = this;

        var name = document.getElementById('name').value.trim();
        var email = document.getElementById('email').value.trim();
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('confirmPassword').value;
        var captchaAnswer = document.getElementById('captchaAnswer').value.trim();
        var valid = true;

        if (!name || name.length < 2) { this.showError('nameError', 'Name must be at least 2 characters'); valid = false; }

        if (!email) { this.showError('emailError', 'Email is required'); valid = false; }
        else if (!this.validateEmail(email)) { this.showError('emailError', 'Only Gmail addresses are allowed'); valid = false; }

        var PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;
        if (!password) { this.showError('passwordError', 'Password is required'); valid = false; }
        else if (!PASSWORD_REGEX.test(password)) { this.showError('passwordError', 'Password does not meet all requirements'); valid = false; }

        if (password !== confirmPassword) { this.showError('confirmPasswordError', 'Passwords do not match'); valid = false; }
        if (!captchaAnswer) { this.showError('captchaError', 'Please answer the security question'); valid = false; }
        if (!valid) return;

        var btn = document.getElementById('signupBtn');
        btn.querySelector('.btn-text').style.display = 'none';
        btn.querySelector('.btn-loader').style.display = 'inline-flex';
        btn.disabled = true;

        API.post('/api/auth/signup', {
            name: name,
            email: email,
            password: password,
            captchaId: self.captchaId,
            captchaAnswer: parseInt(captchaAnswer)
        }).then(function (result) {
            btn.querySelector('.btn-text').style.display = 'inline-flex';
            btn.querySelector('.btn-loader').style.display = 'none';
            btn.disabled = false;

            if (result.success) {
                Toast.success(result.message);
                setTimeout(function () { window.location.href = '/login.html'; }, 2000);
            } else {
                if (result.errors && result.errors.length) {
                    self.showError('passwordError', result.errors.join('. '));
                } else {
                    Toast.error(result.message);
                }
                self.loadCaptcha();
            }
        });
    },

    /* ---------- Floating Message ---------- */
    loadFloatingMessage: function (page) {
        API.get('/api/site-settings').then(function (data) {
            if (!data.success) return;
            var msg = '';
            if (page === 'login' && data.settings.loginMessage) msg = data.settings.loginMessage;
            if (page === 'dashboard' && data.settings.dashboardMessage) msg = data.settings.dashboardMessage;
            if (msg) {
                var banner = document.getElementById('floatingBanner');
                if (banner) { banner.textContent = msg; banner.style.display = 'block'; }
            }
        }).catch(function () {});
    }
};