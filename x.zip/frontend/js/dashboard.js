var Dashboard = {
    user: null,
    charts: {},
    adminFormsReady: false,

    init: function () {
        var self = this;
        API.get('/api/auth/me').then(function (result) {
            if (!result.success) {
                window.location.href = '/login.html';
                return;
            }
            self.user = result.user;
            self.renderUserInfo();
            self.setupNavigation();
            self.setupLogout();
            self.setupSidebarToggle();
            self.setupProfileForms();

            if (self.user.role === 'admin') {
                self.revealAdminUI();
            }

            AuthPage.loadFloatingMessage('dashboard');
            self.showSection('profile');
        });
    },

    renderUserInfo: function () {
        var initials = getInitials(this.user.name);
        document.getElementById('topbarUserName').textContent = this.user.name;
        document.getElementById('topbarAvatar').textContent = initials;
        document.getElementById('profileAvatarLarge').textContent = initials;
        document.getElementById('profileName').textContent = this.user.name;
        document.getElementById('profileEmail').textContent = this.user.email;

        var badges = document.getElementById('profileBadges');
        var html = '';
        if (this.user.verified) html += '<span class="badge badge-verified"><i class="fas fa-check"></i> Verified</span>';
        if (this.user.role === 'admin') html += '<span class="badge badge-admin"><i class="fas fa-crown"></i> Admin</span>';
        if (this.user.provider === 'google') html += '<span class="badge badge-google"><i class="fab fa-google"></i> Google</span>';
        else html += '<span class="badge badge-email"><i class="fas fa-envelope"></i> Email</span>';
        badges.innerHTML = html;

        document.getElementById('detailCreated').textContent = formatDate(this.user.createdAt);
        document.getElementById('detailLastLogin').textContent = formatDate(this.user.lastLogin);
        document.getElementById('detailLoginCount').textContent = this.user.loginCount || 0;
        document.getElementById('detailStatus').textContent = this.user.verified ? 'Active' : 'Unverified';

        document.getElementById('settingsEmail').textContent = this.user.email;
        var vb = document.getElementById('settingsVerified');
        if (this.user.verified) { vb.textContent = 'Verified'; vb.className = 'badge badge-verified'; }
        else { vb.textContent = 'Not Verified'; vb.className = 'badge badge-disabled'; }

        document.getElementById('updateName').value = this.user.name;
    },

    setupNavigation: function () {
        var self = this;
        document.querySelectorAll('.nav-item[data-section]').forEach(function (item) {
            item.addEventListener('click', function () {
                var section = item.dataset.section;
                self.showSection(section);
                document.getElementById('sidebar').classList.remove('open');
                var overlay = document.querySelector('.sidebar-overlay');
                if (overlay) overlay.classList.remove('open');
            });
        });
    },

    showSection: function (name) {
        var self = this;
        document.querySelectorAll('.nav-item[data-section]').forEach(function (item) {
            item.classList.toggle('active', item.dataset.section === name);
        });
        document.querySelectorAll('.content-section').forEach(function (s) { s.classList.remove('active'); });
        var target = document.getElementById('section-' + name);
        if (target) target.classList.add('active');

        var titles = {
            profile: 'Profile', activity: 'Activity', settings: 'Settings',
            'admin-dashboard': 'Admin Dashboard', 'admin-users': 'User Management',
            'admin-site': 'Site Settings', 'admin-security': 'Security Controls'
        };
        document.getElementById('topbarTitle').textContent = titles[name] || 'Dashboard';

        if (name === 'admin-dashboard') self.loadAdminStats();
        if (name === 'admin-users') self.loadAdminUsers();
        if (name === 'admin-site') self.loadSiteSettings();
        if (name === 'admin-security') self.loadSecurityControls();
    },

    setupLogout: function () {
        document.getElementById('logoutBtn').addEventListener('click', function () {
            API.post('/api/auth/logout').then(function () {
                Toast.success('Logged out successfully');
                clearLoggedInUser();
                stopAutoRefresh();
                setTimeout(function () { window.location.href = '/login.html'; }, 600);
            });
        });
    },

    setupProfileForms: function () {
        var self = this;
        document.getElementById('updateProfileForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var name = document.getElementById('updateName').value.trim();
            if (name.length < 2) { Toast.error('Name must be at least 2 characters'); return; }
            API.put('/api/user/profile', { name: name }).then(function (result) {
                if (result.success) { Toast.success('Profile updated'); self.user.name = name; self.renderUserInfo(); }
                else Toast.error(result.message);
            });
        });

        document.getElementById('changePasswordForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var cp = document.getElementById('currentPassword').value;
            var np = document.getElementById('newPassword').value;
            if (!cp || !np) { Toast.error('Both fields are required'); return; }
            if (np.length < 8) { Toast.error('Password must be at least 8 characters'); return; }
            API.put('/api/user/change-password', { currentPassword: cp, newPassword: np }).then(function (result) {
                if (result.success) {
                    Toast.success('Password changed successfully');
                    document.getElementById('currentPassword').value = '';
                    document.getElementById('newPassword').value = '';
                } else Toast.error(result.message);
            });
        });
    },

    revealAdminUI: function () {
        document.querySelectorAll('.admin-only').forEach(function (el) {
            el.style.display = el.tagName === 'BUTTON' ? 'flex' : 'block';
        });
        if (!this.adminFormsReady) {
            this.setupAdminForms();
            this.adminFormsReady = true;
        }
    },

    /* ========== ADMIN: STATS ========== */
    loadAdminStats: function () {
        var self = this;
        API.get('/api/admin/stats').then(function (result) {
            if (!result.success) return;
            var s = result.stats;
            document.getElementById('statTotalUsers').textContent = s.totalUsers;
            document.getElementById('statActiveUsers').textContent = s.activeUsers;
            document.getElementById('statBlockedUsers').textContent = s.blockedUsers;
            document.getElementById('statTotalLogins').textContent = s.totalLogins;

            /* Traffic tabs */
            document.querySelectorAll('.traffic-tab').forEach(function (tab) {
                /* Remove old listeners by cloning */
                var newTab = tab.cloneNode(true);
                tab.parentNode.replaceChild(newTab, tab);

                newTab.addEventListener('click', function () {
                    document.querySelectorAll('.traffic-tab').forEach(function (t) { t.classList.remove('active'); });
                    newTab.classList.add('active');
                    var p = newTab.dataset.period;
                    var vals = {
                        today: { signups: s.todaySignups, logins: s.todayLogins, failed: s.securityLogCount },
                        week: { signups: s.weekSignups, logins: s.weekLogins, failed: s.securityLogCount },
                        month: { signups: s.monthSignups, logins: s.weekLogins, failed: s.securityLogCount },
                        year: { signups: s.yearSignups, logins: s.totalLogins, failed: s.securityLogCount }
                    };
                    var v = vals[p] || vals.today;
                    document.getElementById('tvSignups').textContent = v.signups;
                    document.getElementById('tvLogins').textContent = v.logins;
                    document.getElementById('tvFailed').textContent = v.failed;
                });
            });
            document.querySelector('.traffic-tab[data-period="today"]').click();
            self.renderCharts(s);
        });
    },

    renderCharts: function (stats) {
        var self = this;
        if (typeof Chart === 'undefined') { console.log('[Chart] Chart.js not loaded'); return; }

        Chart.defaults.color = '#a1a1aa';
        Chart.defaults.borderColor = '#27272e';
        Chart.defaults.font.family = "'DM Sans', sans-serif";

        Object.keys(this.charts).forEach(function (k) { try { self.charts[k].destroy(); } catch(e) {} });
        this.charts = {};

        var ctxD = document.getElementById('chartDailyLogins');
        if (ctxD) {
            this.charts.daily = new Chart(ctxD, {
                type: 'line',
                data: {
                    labels: stats.dailyLogins.map(function (d) { return d.date.slice(5); }),
                    datasets: [{
                        label: 'Logins', data: stats.dailyLogins.map(function (d) { return d.count; }),
                        borderColor: '#d4a843', backgroundColor: 'rgba(212,168,67,0.15)',
                        fill: true, tension: 0.4, pointRadius: 2, pointHoverRadius: 5, borderWidth: 2
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } } } }
            });
        }

        var ctxW = document.getElementById('chartWeeklySignups');
        if (ctxW) {
            this.charts.weekly = new Chart(ctxW, {
                type: 'bar',
                data: {
                    labels: stats.weeklySignups.map(function (w) { return w.week; }),
                    datasets: [{
                        label: 'Signups', data: stats.weeklySignups.map(function (w) { return w.count; }),
                        backgroundColor: '#22c55e', borderRadius: 5, maxBarThickness: 28, borderWidth: 0
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } } } }
            });
        }

        var ctxM = document.getElementById('chartMonthlySignups');
        if (ctxM) {
            this.charts.monthly = new Chart(ctxM, {
                type: 'line',
                data: {
                    labels: stats.monthlySignups.map(function (m) { return m.month; }),
                    datasets: [{
                        label: 'Signups', data: stats.monthlySignups.map(function (m) { return m.count; }),
                        borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.15)',
                        fill: true, tension: 0.4, pointRadius: 3, pointHoverRadius: 6,
                        pointBackgroundColor: '#3b82f6', borderWidth: 2
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } } } }
            });
        }

        var ctxP = document.getElementById('chartUserDist');
        if (ctxP) {
            this.charts.dist = new Chart(ctxP, {
                type: 'doughnut',
                data: {
                    labels: ['Active', 'Blocked', 'Unverified'],
                    datasets: [{
                        data: [stats.activeUsers, stats.blockedUsers, stats.unverifiedUsers],
                        backgroundColor: ['#22c55e', '#dc2626', '#6b7280'],
                        borderWidth: 0, hoverOffset: 8
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '65%',
                    plugins: { legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12 } } } }
                }
            });
        }
    },

    /* ========== ADMIN: USERS ========== */
    loadAdminUsers: function () {
        var self = this;
        API.get('/api/admin/users').then(function (result) {
            if (!result.success) return;
            var tbody = document.getElementById('usersTableBody');
            if (!result.users.length) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--db-muted);padding:40px;">No users found</td></tr>';
                return;
            }
            tbody.innerHTML = result.users.map(function (u) {
                var sb = '';
                if (u.blocked) sb += '<span class="badge badge-blocked">Blocked</span> ';
                else if (!u.verified) sb += '<span class="badge badge-disabled">Unverified</span> ';
                else sb += '<span class="badge badge-verified">Active</span> ';
                if (u.role === 'admin') sb += '<span class="badge badge-admin">Admin</span> ';
                if (u.provider === 'google') sb += '<span class="badge badge-google">Google</span>';
                else sb += '<span class="badge badge-email">Email</span>';

                var name = self._esc(u.name);
                var email = self._esc(u.email);
                var id = u.id;

                return '<tr>' +
                    '<td style="color:var(--db-text);font-weight:500;">' + name + '</td>' +
                    '<td style="font-family:var(--db-fh);font-size:0.82rem;">' + email + '</td>' +
                    '<td>' + sb + '</td>' +
                    '<td style="font-family:var(--db-fh);font-weight:600;">' + (u.loginCount || 0) + '</td>' +
                    '<td style="font-size:0.82rem;">' + formatDate(u.lastLogin) + '</td>' +
                    '<td><div class="table-actions">' +
                        '<button class="table-btn info" title="Edit" data-action="edit" data-id="' + id + '"><i class="fas fa-pen"></i></button>' +
                        '<button class="table-btn ' + (u.blocked ? 'success' : 'danger') + '" title="' + (u.blocked ? 'Unblock' : 'Block') + '" data-action="block" data-id="' + id + '"><i class="fas ' + (u.blocked ? 'fa-lock-open' : 'fa-ban') + '"></i></button>' +
                        '<button class="table-btn" title="Reset Password" data-action="reset" data-id="' + id + '" data-name="' + name + '"><i class="fas fa-key"></i></button>' +
                        '<button class="table-btn danger" title="Delete" data-action="delete" data-id="' + id + '"><i class="fas fa-trash"></i></button>' +
                    '</div></td></tr>';
            }).join('');

            /* Attach event listeners via delegation */
            tbody.onclick = function (e) {
                var btn = e.target.closest('.table-btn');
                if (!btn) return;
                var action = btn.dataset.action;
                var id = btn.dataset.id;
                if (action === 'edit') self.openEditModal(id);
                else if (action === 'block') self.toggleBlock(id);
                else if (action === 'reset') self.openResetModal(id, btn.dataset.name);
                else if (action === 'delete') self.deleteUser(id);
            };
        });
    },

    openEditModal: function (userId) {
        var self = this;
        API.get('/api/admin/users').then(function (result) {
            if (!result.success) return;
            var user = result.users.find(function (u) { return u.id === userId; });
            if (!user) { Toast.error('User not found'); return; }
            document.getElementById('editUserId').value = user.id;
            document.getElementById('editUserName').value = user.name;
            document.getElementById('editUserEmail').value = user.email;
            document.getElementById('editUserRole').value = user.role;
            document.getElementById('editUserPassword').value = '';
            document.getElementById('modalTitle').textContent = 'Edit User: ' + user.name;
            document.getElementById('userModal').style.display = 'flex';
        });
    },

    openResetModal: function (userId, userName) {
        document.getElementById('resetUserId').value = userId;
        document.getElementById('resetUserInfo').textContent = 'Reset password for: ' + userName;
        document.getElementById('resetNewPassword').value = '';
        document.getElementById('resetModal').style.display = 'flex';
    },

    toggleBlock: function (userId) {
        var self = this;
        API.put('/api/admin/users/' + userId + '/block').then(function (result) {
            if (result.success) { Toast.success(result.message); self.loadAdminUsers(); }
            else Toast.error(result.message);
        });
    },

    deleteUser: function (userId) {
        if (!confirm('Are you sure you want to delete this user? This cannot be undone.')) return;
        var self = this;
        API.del('/api/admin/users/' + userId).then(function (result) {
            if (result.success) { Toast.success('User deleted'); self.loadAdminUsers(); }
            else Toast.error(result.message);
        });
    },

    /* ========== ADMIN: SITE SETTINGS ========== */
    loadSiteSettings: function () {
        API.get('/api/admin/site-settings').then(function (result) {
            if (!result.success) return;
            var s = result.settings;
            document.getElementById('siteTitle').value = s.homepageTitle || '';
            document.getElementById('siteDescription').value = s.homepageDescription || '';
            document.getElementById('loginMsg').value = s.loginMessage || '';
            document.getElementById('dashMsg').value = s.dashboardMessage || '';
            document.getElementById('privacyContent').value = s.privacyPolicy || '';
        });
    },

    setupAdminForms: function () {
        var self = this;

        /* Edit modal */
        var closeModal = function (id) { document.getElementById(id).style.display = 'none'; };
        document.getElementById('modalClose').addEventListener('click', function () { closeModal('userModal'); });
        document.getElementById('modalCancel').addEventListener('click', function () { closeModal('userModal'); });
        document.getElementById('userModal').addEventListener('click', function (e) { if (e.target.id === 'userModal') closeModal('userModal'); });

        document.getElementById('userEditForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var id = document.getElementById('editUserId').value;
            var body = {
                name: document.getElementById('editUserName').value.trim(),
                email: document.getElementById('editUserEmail').value.trim(),
                role: document.getElementById('editUserRole').value
            };
            var pw = document.getElementById('editUserPassword').value;
            if (pw) body.password = pw;
            API.put('/api/admin/users/' + id, body).then(function (result) {
                if (result.success) { Toast.success('User updated'); closeModal('userModal'); self.loadAdminUsers(); }
                else Toast.error(result.message);
            });
        });

        /* Reset modale */
        document.getElementById('resetModalClose').addEventListener('click', function () { closeModal('resetModal'); });
        document.getElementById('resetModalCancel').addEventListener('click', function () { closeModal('resetModal'); });
        document.getElementById('resetModal').addEventListener('click', function (e) { if (e.target.id === 'resetModal') closeModal('resetModal'); });

        document.getElementById('resetPasswordForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var id = document.getElementById('resetUserId').value;
            var pw = document.getElementById('resetNewPassword').value;
            if (!pw || pw.length < 8) { Toast.error('Password must be at least 8 characters'); return; }
            API.put('/api/admin/users/' + id + '/reset-password', { newPassword: pw }).then(function (result) {
                if (result.success) { Toast.success('Password reset successfully'); closeModal('resetModal'); }
                else Toast.error(result.message);
            });
        });

        /* Homepage */
        document.getElementById('homepageForm').addEventListener('submit', function (e) {
            e.preventDefault();
            API.put('/api/admin/site-settings', {
                homepageTitle: document.getElementById('siteTitle').value.trim(),
                homepageDescription: document.getElementById('siteDescription').value.trim()
            }).then(function (r) { Toast.success(r.success ? 'Homepage updated' : r.message); });
        });

        /* Messages */
        document.getElementById('messagesForm').addEventListener('submit', function (e) {
            e.preventDefault();
            API.put('/api/admin/site-settings', {
                loginMessage: document.getElementById('loginMsg').value.trim(),
                dashboardMessage: document.getElementById('dashMsg').value.trim()
            }).then(function (r) { Toast.success(r.success ? 'Messages updated' : r.message); });
        });

        /* Privacy */
        document.getElementById('privacyForm').addEventListener('submit', function (e) {
            e.preventDefault();
            API.put('/api/admin/site-settings', {
                privacyPolicy: document.getElementById('privacyContent').value
            }).then(function (r) { Toast.success(r.success ? 'Privacy policy updated' : r.message); });
        });

        /* IP block */
        document.getElementById('ipBlockForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var ip = document.getElementById('ipInput').value.trim();
            if (!ip) { Toast.error('Enter an IP address'); return; }
            API.post('/api/admin/blocked-ips', { ip: ip, action: 'block' }).then(function (result) {
                if (result.success) { Toast.success('IP blocked'); document.getElementById('ipInput').value = ''; self.loadSecurityControls(); }
                else Toast.error(result.message);
            });
        });
    },

    /* ========== ADMIN: SECURITY ========== */
    loadSecurityControls: function () {
        var self = this;

        API.get('/api/admin/stats').then(function (result) {
            if (!result.success) return;
            var ips = result.stats.blockedIPs;
            var list = document.getElementById('blockedIPsList');
            if (!ips.length) {
                list.innerHTML = '<p class="muted-text">No blocked IPs</p>';
            } else {
                list.innerHTML = ips.map(function (ip) {
                    return '<span class="blocked-ip-tag">' + self._esc(ip) +
                        ' <button data-unblock="' + self._esc(ip) + '" title="Unblock"><i class="fas fa-xmark"></i></button></span>';
                }).join('');

                /* Delegate unblock clicks */
                list.onclick = function (e) {
                    var btn = e.target.closest('[data-unblock]');
                    if (!btn) return;
                    self.unblockIP(btn.dataset.unblock);
                };
            }
        });

        API.get('/api/admin/security-logs').then(function (result) {
            if (!result.success) return;
            var container = document.getElementById('securityLogsContainer');
            if (!result.logs.length) {
                container.innerHTML = '<p class="muted-text">No security logs</p>';
            } else {
                container.innerHTML = result.logs.slice(0, 100).map(function (log) {
                    var tc = (log.type.indexOf('BLOCK') !== -1 || log.type.indexOf('FAIL') !== -1 || log.type.indexOf('INJECTION') !== -1) ? 'danger' : 'warning';
                    var ip = self._esc(log.ip || 'unknown');
                    var path = self._esc(log.path || '');
                    var ua = log.userAgent ? self._esc(log.userAgent.slice(0, 50)) : '';
                    var time = log.timestamp ? log.timestamp.slice(0, 19) : '';
                    return '<div class="log-entry"><span class="log-type ' + tc + '">' + self._esc(log.type) + '</span>' +
                        '<span style="color:var(--db-muted);">' + ip + '</span> ' +
                        '<span style="color:var(--db-text2);">' + path + (ua ? ' — ' + ua : '') + '</span> ' +
                        '<span style="color:var(--db-muted);float:right;font-size:0.72rem;">' + time + '</span></div>';
                }).join('');
            }
        });
    },

    unblockIP: function (ip) {
        var self = this;
        API.post('/api/admin/blocked-ips', { ip: ip, action: 'unblock' }).then(function (result) {
            if (result.success) { Toast.success('IP unblocked'); self.loadSecurityControls(); }
            else Toast.error(result.message);
        });
    },

    setupSidebarToggle: function () {
        var sidebar = document.getElementById('sidebar');
        var toggle = document.getElementById('sidebarToggle');
        var overlay = document.createElement('div');
        overlay.className = 'sidebar-overlay';
        document.body.appendChild(overlay);

        toggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('open');
        });
        overlay.addEventListener('click', function () {
            sidebar.classList.remove('open');
            overlay.classList.remove('open');
        });
    },

    _esc: function (str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
};

document.addEventListener('DOMContentLoaded', function () { Dashboard.init(); });
