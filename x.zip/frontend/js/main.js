var API_BASE = (window.__API_URL__ || '').replace(/\/+$/, '');

/* ===== Auto Refresh: every 55 min, no idle timeout ===== */
var _refreshInterval = null;

function startAutoRefresh() {
    stopAutoRefresh();
    API.refreshTokenSilent();
    _refreshInterval = setInterval(function () {
        API.refreshTokenSilent();
    }, 55 * 60 * 1000);
}

function stopAutoRefresh() {
    if (_refreshInterval) { clearInterval(_refreshInterval); _refreshInterval = null; }
}

/* ===== Session state ===== */
var _loggedInUser = null;

function setLoggedInUser(user) {
    _loggedInUser = user;
    updateAllButtons(user);
}

function clearLoggedInUser() {
    _loggedInUser = null;
    updateAllButtons(null);
}

/*
 * Updates Login → Dashboard button everywhere on the page.
 * Called after every session check and login/logout.
 */
function updateAllButtons(user) {
    var isLogged = !!user;

    /* Hero login button → Dashboard */
    var heroLogin = document.getElementById('heroLoginBtn');
    if (heroLogin) {
        if (isLogged) {
            heroLogin.href = '/dashboard.html';
            heroLogin.innerHTML = '<i class="fas fa-gauge-high"></i> Dashboard';
            heroLogin.className = 'btn btn-primary';
        } else {
            heroLogin.href = '/login.html';
            heroLogin.innerHTML = '<i class="fas fa-right-to-bracket"></i> Login';
            heroLogin.className = 'btn btn-outline';
        }
    }

    /* Hero signup button — hide when logged in */
    var heroSignup = document.getElementById('heroSignupBtn');
    if (heroSignup) {
        heroSignup.style.display = isLogged ? 'none' : 'inline-flex';
    }

    /* 3-dot menu: hide Login/Signup, show Dashboard when logged in */
    var mLogin = document.getElementById('menuLoginItem');
    var mSignup = document.getElementById('menuSignupItem');
    var mDash = document.getElementById('menuDashItem');

    if (mLogin) mLogin.style.display = isLogged ? 'none' : 'flex';
    if (mSignup) mSignup.style.display = isLogged ? 'none' : 'flex';
    if (mDash) mDash.style.display = isLogged ? 'flex' : 'none';
}

/*
 * Check session on every page load.
 * Calls /api/auth/me with cookies.
 * If valid → buttons become Dashboard.
 * If expired → tries silent refresh → rechecks.
 * If dead → buttons stay as Login.
 */
function checkSession() {
    return fetch(API_BASE + '/api/auth/me', {
        method: 'GET',
        credentials: 'include'
    })
    .then(function (res) { return res.json(); })
    .then(function (data) {
        if (data.success && data.user) {
            setLoggedInUser(data.user);
            startAutoRefresh();
            return data;
        }

        /* Access token expired — try one silent refresh */
        if (data.code === 'TOKEN_EXPIRED') {
            return API.refreshTokenSilent().then(function (ok) {
                if (ok) return checkSession();
                clearLoggedInUser();
                stopAutoRefresh();
                return null;
            });
        }

        clearLoggedInUser();
        stopAutoRefresh();
        return null;
    })
    .catch(function (err) {
        console.log('[Session] Check failed:', err);
        clearLoggedInUser();
        stopAutoRefresh();
        return null;
    });
}

/* ===== Toast ===== */
var Toast = {
    container: null,
    init: function () {
        this.container = document.getElementById('toastContainer');
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.className = 'toast-container';
            this.container.id = 'toastContainer';
            document.body.appendChild(this.container);
        }
    },
    show: function (message, type, duration) {
        type = type || 'info'; duration = duration || 4000;
        if (!this.container) this.init();
        var icons = { success:'fa-circle-check', error:'fa-circle-xmark', info:'fa-circle-info', warning:'fa-triangle-exclamation' };
        var toast = document.createElement('div');
        toast.className = 'toast ' + type;
        toast.innerHTML = '<i class="fas ' + (icons[type]||icons.info) + ' toast-icon"></i><span>' + this._esc(message) + '</span>';
        this.container.appendChild(toast);
        setTimeout(function () { toast.classList.add('removing'); setTimeout(function () { toast.remove(); }, 200); }, duration);
    },
    success: function (m) { this.show(m,'success'); },
    error: function (m) { this.show(m,'error',5000); },
    info: function (m) { this.show(m,'info'); },
    warning: function (m) { this.show(m,'warning'); },
    _esc: function (s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
};

/* ===== API Helper ===== */
var API = {
    request: function (url, options) {
        options = options || {};
        var fullUrl = API_BASE + url;
        var config = {
            headers: Object.assign({ 'Content-Type': 'application/json' }, options.headers || {}),
            credentials: 'include'
        };
        if (options.method) config.method = options.method;
        if (options.body && typeof options.body === 'object') config.body = JSON.stringify(options.body);

        var self = this;
        return fetch(fullUrl, config).then(function (response) {
            if (response.status === 401) {
                return response.json().then(function (data) {
                    if (data.code === 'TOKEN_EXPIRED') {
                        return self.refreshToken().then(function (ok) {
                            if (ok) return fetch(fullUrl, config).then(function (r) { return r.json(); });
                            clearLoggedInUser(); stopAutoRefresh();
                            window.location.href = '/login.html';
                            return { success: false, message: 'Session expired' };
                        });
                    }
                    clearLoggedInUser(); stopAutoRefresh();
                    window.location.href = '/login.html';
                    return { success: false, message: 'Session expired' };
                });
            }
            return response.json();
        }).catch(function () {
            return { success: false, message: 'Network error.' };
        });
    },

    refreshToken: function () {
        return fetch(API_BASE + '/api/auth/refresh', { method: 'POST', credentials: 'include' })
            .then(function (r) { return r.ok; }).catch(function () { return false; });
    },

    refreshTokenSilent: function () {
        return fetch(API_BASE + '/api/auth/refresh', { method: 'POST', credentials: 'include' })
            .then(function (r) {
                if (r.ok) return true;
                clearLoggedInUser(); stopAutoRefresh();
                return false;
            }).catch(function () { return false; });
    },

    get: function (u) { return this.request(u); },
    post: function (u, b) { return this.request(u, { method: 'POST', body: b }); },
    put: function (u, b) { return this.request(u, { method: 'PUT', body: b }); },
    del: function (u) { return this.request(u, { method: 'DELETE' }); }
};

/* ===== Utilities ===== */
function formatDate(d) {
    if (!d) return '--';
    var dt = new Date(d); if (isNaN(dt.getTime())) return '--';
    return dt.toLocaleDateString('en-US', { year:'numeric', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
}
function getInitials(n) {
    if (!n) return '?';
    return n.split(' ').map(function (w) { return w[0]; }).join('').toUpperCase().slice(0,2);
}

/* ===== On DOM ready ===== */
document.addEventListener('DOMContentLoaded', function () {
    Toast.init();

    /* 3-dot menu toggle */
    var mt = document.getElementById('menuDropdown');
    var mp = document.getElementById('menuPanel');
    if (mt && mp) {
        mt.querySelector('.menu-trigger').addEventListener('click', function (e) {
            e.stopPropagation(); mp.classList.toggle('open');
        });
        document.addEventListener('click', function (e) {
            if (!mt.contains(e.target)) mp.classList.remove('open');
        });
    }

    /* Check session — this updates buttons after API responds */
    checkSession();

    /* Load dynamic site title/description */
    var ht = document.getElementById('heroTitle');
    var hd = document.getElementById('heroDescription');
    if (ht && hd) {
        API.get('/api/site-settings').then(function (d) {
            if (d.success) {
                if (d.settings.homepageTitle) ht.textContent = d.settings.homepageTitle;
                if (d.settings.homepageDescription) hd.textContent = d.settings.homepageDescription;
            }
        }).catch(function () {});
    }
});
