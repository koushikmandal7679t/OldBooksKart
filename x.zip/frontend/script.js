const API_URL = 'http://localhost:5000';
let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    loadFloatingMessages('login');
    loadPrivacyPolicy();
    setupEventListeners();
    checkAuthStatus();
});

function setupEventListeners() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    
    const signupForm = document.getElementById('signupForm');
    if (signupForm) signupForm.addEventListener('submit', handleSignup);
    
    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });
    
    const loginNavBtn = document.getElementById('loginNavBtn');
    if (loginNavBtn) loginNavBtn.addEventListener('click', openLoginModal);
    
    const signupNavBtn = document.getElementById('signupNavBtn');
    if (signupNavBtn) signupNavBtn.addEventListener('click', openSignupModal);
    
    const privacyPolicyLink = document.getElementById('privacyPolicyLink');
    if (privacyPolicyLink) privacyPolicyLink.addEventListener('click', openPrivacyModal);
    
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            const navLinks = document.querySelector('.nav-links');
            if (navLinks) {
                navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
            }
        });
    }
    
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    };
}

async function checkAuthStatus() {
    const token = localStorage.getItem('token') || getCookie('token');
    if (token) {
        try {
            const response = await fetch(`${API_URL}/api/user`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                const user = await response.json();
                currentUser = user;
                if (!window.location.pathname.includes('dashboard') && 
                    !window.location.pathname.includes('admin')) {
                    window.location.href = 'dashboard.html';
                }
            }
        } catch (error) {
            console.error('Auth check failed:', error);
        }
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.token) {
            localStorage.setItem('token', data.token);
            showFloatingMessage('Login successful! Redirecting...', 'success');
            setTimeout(() => {
                if (data.role === 'admin') {
                    window.location.href = 'admin.html';
                } else {
                    window.location.href = 'dashboard.html';
                }
            }, 1000);
        } else if (data.error === 'verify') {
            showFloatingMessage('Please verify your email before logging in', 'warning');
        } else {
            showFloatingMessage(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showFloatingMessage('Network error. Please try again.', 'error');
    }
}

async function handleSignup(e) {
    e.preventDefault();
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    if (!agreeTerms) {
        showFloatingMessage('Please agree to the Terms & Privacy Policy', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showFloatingMessage('Verification email sent! Check your inbox', 'success');
            setTimeout(() => {
                document.getElementById('signupModal').style.display = 'none';
                document.getElementById('signupForm').reset();
            }, 2000);
        } else {
            showFloatingMessage(data.error || 'Signup failed', 'error');
        }
    } catch (error) {
        showFloatingMessage('Network error. Please try again.', 'error');
    }
}

function googleLogin() {
    window.location.href = `${API_URL}/auth/google`;
}

function openLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
    document.getElementById('signupModal').style.display = 'none';
}

function openSignupModal() {
    document.getElementById('signupModal').style.display = 'block';
    document.getElementById('loginModal').style.display = 'none';
}

function switchToLogin() {
    openLoginModal();
}

function switchToSignup() {
    openSignupModal();
}

async function openPrivacyModal() {
    const modal = document.getElementById('privacyModal');
    const content = document.getElementById('privacyContent');
    modal.style.display = 'block';
    
    try {
        const response = await fetch(`${API_URL}/api/privacy-policy`);
        const data = await response.json();
        content.innerHTML = `<div class="privacy-text" style="line-height: 1.6; color: #334155;">${data.content.replace(/\n/g, '<br>')}</div>`;
    } catch (error) {
        content.innerHTML = '<p style="color: #ef4444;">Unable to load privacy policy</p>';
    }
}

async function loadFloatingMessages(page) {
    try {
        const response = await fetch(`${API_URL}/api/floating-messages`);
        const messages = await response.json();
        
        const activeMessages = messages.filter(m => m.active && (m.page === 'all' || m.page === page));
        activeMessages.forEach(msg => {
            setTimeout(() => {
                showFloatingMessage(msg.text, msg.type, msg.duration);
            }, 500);
        });
    } catch (error) {
        console.error('Failed to load messages:', error);
    }
}

function showFloatingMessage(text, type = 'info', duration = 5000) {
    const container = document.getElementById('floatingMessages');
    const message = document.createElement('div');
    message.className = `floating-message ${type}`;
    
    let icon = '';
    if (type === 'success') icon = '✓';
    else if (type === 'error') icon = '✗';
    else if (type === 'warning') icon = '!';
    else icon = 'i';
    
    message.innerHTML = `<span style="font-weight: 700;">${icon}</span><span>${text}</span>`;
    
    container.appendChild(message);
    
    setTimeout(() => {
        message.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => message.remove(), 300);
    }, duration);
}

async function loadPrivacyPolicy() {
    try {
        const response = await fetch(`${API_URL}/api/privacy-policy`);
        const data = await response.json();
        window.privacyContent = data.content;
    } catch (error) {
        console.error('Failed to load privacy policy:', error);
    }
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}
