const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname)));

/* Works in both Express v4 and v5 */
app.get('{*path}', function (req, res, next) {
    var filePath = path.join(__dirname, req.params.path ? '/' + req.params.path : '/index.html');
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        res.sendFile(filePath);
    } else {
        res.sendFile(path.join(__dirname, 'index.html'));
    }
});

app.use(function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, function () {
    console.log('========================================');
    console.log('  Frontend Server Started');
    console.log('  URL: http://localhost:' + PORT);
    console.log('========================================');
});
